<?php

define('W3STYLE',true);
include('../#includes/config.php');
include('../#includes/cp.class.php');
include('version.php');
if(strpos($_SERVER['HTTP_USER_AGENT'],'MSIE 6')!=0) {
    echo 'Dung trinh duyet khac';
}

elseif(check_log()) {
    $tpl = new Template('main.html');
    $menu = isset($_GET['m'])?$_GET['m']:'0';
    $sub_menu = isset($_GET['sm'])?$_GET['sm']:'0';
    switch($menu) {
        // Bảng điều khiển
        case '0':            
            $this_menu = '| Bảng điều khiển';
			$list_temp = @mysql_query("SELECT * FROM w3style_templates");
            while ($listtemp = @mysql_fetch_array ($list_temp)){
                $tpl->assign(
                    array(
                        'tpl_id' => $listtemp['id'],
                        'tpl_name' => $listtemp['tpl_name'],
                        'tpl_dir' => $listtemp['tpl_dir'],
                        'tpl_active' => ($listtemp['tpl_active'] == '1')?'checked':'',
                    ));
                $tpl->parse('list_temp');
            }
			list($totalvisit) = @mysql_fetch_array(@mysql_query("SELECT MAX(id) FROM w3style_onlines"));
			$tpl->assign(
                array(
                    'total_post' => @mysql_num_rows(@mysql_query("SELECT id FROM w3style_posts WHERE post_type = 1")),
                    'total_product' => @mysql_num_rows(@mysql_query("SELECT id FROM w3style_products")),
					'total_video' => @mysql_num_rows(@mysql_query("SELECT id FROM w3style_videos")),
					'total_album' => @mysql_num_rows(@mysql_query("SELECT id FROM w3style_album")),
                    'total_online' => @mysql_num_rows(@mysql_query("SELECT id FROM w3style_onlines")),
                    'total_visit' => $totalvisit,
                ));
            break;
        
			case '5':
			$this_menu = '| Code';
			switch($sub_menu) {
			case '0':
				$this_menu .= ' | Thêm code';
			break;
					
			case '1':				
				$current_page = ($_GET['page'])?$_GET['page']:1;
				$u_start = ($current_page -1) * get_option('paging');
				$total_u = @mysql_num_rows(@mysql_query("SELECT id FROM w3style_code"));
				$code_list = @mysql_query("SELECT * FROM w3style_code ".$u_where." ORDER BY id DESC LIMIT ".$u_start.",".get_option('paging'));				
				
				while ($lcode = @mysql_fetch_array ($code_list)){	
					$tpl->assign(
						array(
							'lcode_id' => $lcode['id'],
							'lcode_name' => $lcode['code_name'],
							'lcode_note' => $lcode['code_note'],
							'lcode_status' => ($lcode['code_status'] == 0)?'style="background: #900;" role="button">Không kích hoạt':'style="background: #090;" role="button">Kích hoạt',
						));

					$tpl->parse('list_code');
				}
				$tpl->assign('lc_paging',paging(get_option('paging'),$current_page, $total_u, 'index.php?m=5&sm=1',$modpage.'&page=' ,false));
				$this_menu .= ' | Danh sách';
			break;
			
			case '2':
				$ecode = @mysql_fetch_array(@mysql_query("SELECT * FROM w3style_code WHERE id = ".$_GET['id']));
				$tpl->assign(
					array(
						'my_id' => $_GET['id'],
						'name' => $ecode['code_name'],
						'note' => $ecode['code_note'],
						'status' => ($ecode['code_status']==1)?"checked":"",
					));		  
				
				
			break;
			}
		break;
		
    }	
	
	if(check_level() >= 2 && !in_array($menu, array('1', '5', '6', '7', '8'))) {
        $tpl->parse('cp_'.$menu.'_'.$sub_menu);
    }
    elseif(check_level() >= 3 && !in_array($menu, array('1', '6', '7', '8'))) {
        $tpl->parse('cp_'.$menu.'_'.$sub_menu);
    }
    elseif(check_level() >= 4 && !in_array($menu, array('6', '9'))) {
        $tpl->parse('cp_'.$menu.'_'.$sub_menu);
    }
    elseif(check_level() >= 9) {
        $tpl->parse('cp_'.$menu.'_'.$sub_menu);
    }
	elseif(check_level() == 1 OR check_level() == 0) {
		Redirect("Không có quyền truy cập", "w3style-logout.php");
	}
	
    $menu_level = '';
	if(check_level() >= 4) $menu_level .= @file_get_contents('templates/level_4.html');
    if(check_level() >= 2) $menu_level .= @file_get_contents('templates/level_2.html');
    if(check_level() >= 3) $menu_level .= @file_get_contents('templates/level_3.html');    
    if(check_level() >= 9) $menu_level .= @file_get_contents('templates/level_9.html');
	
	$if_user = @mysql_fetch_array(@mysql_query("SELECT * FROM w3style_users WHERE id = ".$_SESSION['user']['id']));
	$q_list_unread = @mysql_query("SELECT * FROM w3style_messages WHERE message_read = '0' AND message_to = ".$_SESSION['user']['id']." ORDER BY id DESC");
	while($list_unread = @mysql_fetch_array($q_list_unread)) {
		$msg_from = @mysql_fetch_array(@mysql_query("SELECT * FROM w3style_users WHERE id = ".$_SESSION['user']['id']));
		$tpl->assign(
			array(
				'msg_from_name' => $msg_from['user_fullname'],
				'msg_from_avatar' => ($msg_from['user_avatar'] == null)?"../s-panel/templates/assets/img/find_user.png":$msg_from['user_avatar'],
				'message_content' => catchuoi(strip_tags($list_unread['message_content']), 10),
			));
		$tpl->parse('list_unread');
	}
	$last_visit = @mysql_fetch_array(@mysql_query("SELECT user_lastvisit FROM w3style_users WHERE id = ".$_SESSION['user']['id']));
    $tpl->assign(
        array(
			'menu_level' => $menu_level,
            'version' => $version['name'].' '.$version['value'],
            'this_menu' => $this_menu,
			'name_user' => $if_user['user_fullname'],
			'avatar_user' =>($if_user['user_avatar'] == null)?"../s-panel/templates/assets/img/find_user.png":$if_user['user_avatar'],
            'messages_new' => @mysql_num_rows(@mysql_query("SELECT id FROM w3style_messages WHERE message_read = '0' AND message_to = ".$_SESSION['user']['id'])),
            'total_user' => @mysql_num_rows(@mysql_query("SELECT id FROM w3style_users")),
			'last_visit' => formatTime($last_visit['user_lastvisit'], 4),
            'menu' => $menu,
            'username' => get_option("username"),
            'password' => get_option("password"),
            'sub_menu' => $sub_menu,
        ));
    $tpl->tpl_out();
	$sql = @mysql_query("UPDATE w3style_users SET user_lastvisit = ". time() ." WHERE  id = ".$_SESSION['user']['id']);
}

else header('Location: w3style-login.php');

?>