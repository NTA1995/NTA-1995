<?php
define('W3STYLE',true);
include('../#includes/config.php');

if($_POST['nick']){
	$nick = addslashes($_POST['nick']);
	list($check_salt) = @mysql_fetch_array(@mysql_query("SELECT user_salt FROM w3style_users WHERE user_nick = '".$nick."'"));
	$pass = md5(md5($_POST['pass']).$check_salt);

    list($check) = @mysql_fetch_array(@mysql_query("SELECT id FROM w3style_users WHERE user_nick = '".$nick."' and user_password = '".$pass."'"));
	if($check >= 1) {
        $_SESSION['user']['id'] = $check;
        $_SESSION['user']['pass'] = md5(md5($_POST['pass']).$check_salt);
        header('Location: index.php');
    }
    else {
		Redirect("Tài khoản hoặc mật khẩu không đúng", 'w3style-login.php?nick='.$_POST['nick']);
	}
}
else echo 'Hacking attempt';

?>