<?php
define('W3STYLE',true);
include('../#includes/config.php');
if(check_log() == true) {
    $_POST['status'] = ($_POST['status'])?$_POST['status']:0;
    if($_GET['type'] == 'add' && check_level() == 9){
        @mysql_query("INSERT INTO w3style_code (code_name, code_note, code_status) VALUES ('".$_POST['name']."', '".$_POST['note']."', ".$_POST['status'].")");
        header('Location: index.php?m=5&sm=1');
        
    }

    elseif($_GET['type'] == 'edit' && check_level() == 9){
        @mysql_query("UPDATE w3style_code SET code_name = '".$_POST['name']."', code_note = '".$_POST['note']."', code_status = ".$_POST['status']." WHERE id = ".$_POST['id']);
        header('Location: index.php?m=5&sm=1');
    }
    
    elseif($_GET['type'] == 'del' && check_level() == 9){
        $total = count($_POST['id']);
        for($i=0; $i<$total; $i++) {
            @mysql_query("DELETE FROM w3style_code WHERE id = ".$_POST['id'][$i]);
        }
        header('Location: index.php?m=5&sm=1');
    }
    
    else echo "Hacking attempt";
}

?>