<?php

define('W3STYLE',true);
include('../#includes/config.php');
include('../#includes/cp.class.php');
include('version.php');
if(strpos($_SERVER['HTTP_USER_AGENT'],'MSIE 6')!=0) {
    echo 'Dung trinh duyet khac';
}

elseif(check_log()) {
    $tpl = new Template('main.html');
    $menu = isset($_GET['m'])?$_GET['m']:'0';
    $sub_menu = isset($_GET['sm'])?$_GET['sm']:'0';
    switch($menu) {
        // Bảng điều khiển
        case '0':            
            $this_menu = '| Bảng điều khiển';
			$list_temp = @mysql_query("SELECT * FROM w3style_templates");
            while ($listtemp = @mysql_fetch_array ($list_temp)){
                $tpl->assign(
                    array(
                        'tpl_id' => $listtemp['id'],
                        'tpl_name' => $listtemp['tpl_name'],
                        'tpl_dir' => $listtemp['tpl_dir'],
                        'tpl_active' => ($listtemp['tpl_active'] == '1')?'checked':'',
                    ));
                $tpl->parse('list_temp');
            }
			list($totalvisit) = @mysql_fetch_array(@mysql_query("SELECT MAX(id) FROM w3style_onlines"));
			$tpl->assign(
                array(
                    'total_post' => @mysql_num_rows(@mysql_query("SELECT id FROM w3style_posts WHERE post_type = 1")),
                    'total_product' => @mysql_num_rows(@mysql_query("SELECT id FROM w3style_products")),
					'total_video' => @mysql_num_rows(@mysql_query("SELECT id FROM w3style_videos")),
					'total_album' => @mysql_num_rows(@mysql_query("SELECT id FROM w3style_album")),
                    'total_online' => @mysql_num_rows(@mysql_query("SELECT id FROM w3style_onlines")),
                    'total_visit' => $totalvisit,
                ));
            break;
        // Danh mục
        case '1':
			$this_menu = '| Danh mục';
			switch($sub_menu) {
				case '0':
				list($cat_seting1) = @mysql_fetch_array(@mysql_query("SELECT mod_home FROM w3style_modules WHERE id = '6'"));
				$sub_cat = @mysql_query("SELECT id, mod_name FROM w3style_modules WHERE mod_home = '1' AND mod_type = 'menu' ORDER BY id ASC");
					while ($listsub_kieu = @mysql_fetch_array ($sub_cat)){
						$tpl->assign(
							array(
								'kieu_id' => $listsub_kieu['id'],
								'kieu_name' => $listsub_kieu['mod_name'],
							));
				  
				if($_GET['id'] > 0){
					
					$cat = @mysql_fetch_array(@mysql_query("SELECT * FROM w3style_cats WHERE id = ".$_GET['id']));
					$tpl->assign(
						array(
							'ecat_action' => 'edit',
							'ecat_id' => $cat['id'],
							'ecat_name' => $cat['cat_name'],
							'ecat_desc' => $cat['cat_info'],
							'ecat_order' => $cat['cat_order'],
							'cat_type' => $cat['cat_type'],
							'cat_img' => $cat['cat_img'],
							'cat_img_cf' => ($cat_seting1['mod_home'] == 1)?'<div class="content">    
					<input type="button" value="Chọn ảnh minh họa" onclick="$.showAkModal(\'../data/javascripts/editor/popups/insert_imgdemo.php?type=up\',\'Image\',450,400);" />
					<br />
					<p align="right" id="imgdemos" style="margin-top: 5px;"><img style="max-width: 120px; border: 1px solid #cbcbcb" src="'.$cat['cat_img'].'" />
						<input type="hidden" name="img" value="'.$cat['cat_img'].'" /></p>
				</div>':'',
							'ecat_bt' => 'Sửa',
							'ecat_kieushow' => ($listsub_kieu['id'] == $cat['cat_type'])?'selected':'',
						));
				}
				else {
					
					$tpl->assign(
						array(
							'ecat_action' => 'add',
							'ecat_id' => '',
							'ecat_name' => 'Tiêu đề" onfocus="if(this.value==\'Tiêu đề\')this.value=\'\'" onblur="if(this.value==\'\')this.value=\'Tiêu đề\'',
							'ecat_desc' => '',
							'ecat_order' => '1" onfocus="if(this.value==\'1\')this.value=\'\'" onblur="if(this.value==\'\')this.value=\'1\'',
							'ecat_bt' => 'Thêm danh mục',
							'cat_img_cf' => ($cat_seting1['mod_home'] == 1)?'<div class="content">    
					<input type="button" value="Chọn ảnh minh họa" onclick="$.showAkModal(\'../data/javascripts/editor/popups/insert_imgdemo.php?type=up\',\'Image\',450,400);" />
					<br />
					<p align="right" id="imgdemos" style="margin-top: 5px;"><img style="max-width: 120px; border: 1px solid #cbcbcb" src="'.$cat['cat_img'].'" />
						<input type="hidden" name="img" value="'.$cat['cat_img'].'" /></p>
				</div>':'',
						));
				}
				$tpl->parse('chonkieumodule');
				 
				  }
				$cat1 = @mysql_fetch_array(@mysql_query("SELECT id, cat_name, cat_info, cat_order, cat_sub, cat_home FROM w3style_cats WHERE id = ".$_GET['id']));
				$cat_list = @mysql_query("SELECT * FROM w3style_cats WHERE cat_sub = 0 ORDER BY cat_order ASC");    
				while ($lcat = @mysql_fetch_array ($cat_list)){
					list($p_lcat_chon) = @mysql_fetch_array(@mysql_query("SELECT mod_name FROM w3style_modules WHERE id = ".$lcat['cat_type']));
					if($_GET['id'] != $lcat['id']) {
						 $cat_list2 = @mysql_query("SELECT * FROM w3style_cats WHERE cat_sub = ".$lcat['id']." ORDER BY cat_order ASC");
							while ($listsub2 = @mysql_fetch_array ($cat_list2)){
								
								$cat_list3 = @mysql_query("SELECT id, cat_name, cat_sub, cat_order FROM w3style_cats WHERE cat_sub = ".$listsub2['id']." ORDER BY cat_order ASC");
									while ($listsub3 = @mysql_fetch_array ($cat_list3)){
										
										$cat_list4 = @mysql_query("SELECT id, cat_name, cat_sub, cat_order FROM w3style_cats WHERE cat_sub = ".$listsub3['id']." ORDER BY cat_order ASC");
											while ($listsub4 = @mysql_fetch_array ($cat_list4)){
												$tpl->assign(
													array(
														'cat_id4' => $listsub4['id'],
														'cat_name4' => $listsub4['cat_name'],
														'cat_sub4' => $listsub3['id'],
														));
												$tpl->parse('add_cat4');
										}
								
									$tpl->assign(
										array(
											'cat_id3' => $listsub3['id'],
											'cat_name3' => $listsub3['cat_name'],
											'ecat_check3' => ($listsub3['id'] == $cat['cat_sub'])?'selected=""':'',

										));
									$tpl->parse('add_cat3');
								}
						  
								$tpl->assign(
								array(
									'cat_id2' => $listsub2['id'],
									'cat_name2' => $listsub2['cat_name'],
									'ecat_check2' => ($listsub2['id'] == $cat['cat_sub'])?'selected=""':'',
									));
								$tpl->parse('add_cat2');
						  }
						  
						$tpl->assign(
							array(
								'cat_id' => $lcat['id'],
								'cat_name' => $lcat['cat_name'],
								'ecat_check' => ($lcat['id'] == $cat['cat_sub'])?'selected=""':'',
							));
						$tpl->parse('add_cat');
					}//End menu da cap
					$sub_cat = @mysql_query("SELECT * FROM w3style_cats WHERE cat_sub = ".$lcat['id']." ORDER BY cat_order ASC");
					while ($listsub = @mysql_fetch_array ($sub_cat)){
						list($p_cat_chon) = @mysql_fetch_array(@mysql_query("SELECT mod_name FROM w3style_modules WHERE id = ".$listsub['cat_type']));
						$sub_cat1 = @mysql_query("SELECT * FROM w3style_cats WHERE cat_sub = ".$listsub['id']." ORDER BY cat_order ASC");
							while ($listsub1 = @mysql_fetch_array ($sub_cat1)){
								list($p_cat_chon1) = @mysql_fetch_array(@mysql_query("SELECT mod_name FROM w3style_modules WHERE id = ".$listsub1['cat_type']));
							$sub_cat2 = @mysql_query("SELECT * FROM w3style_cats WHERE cat_sub = ".$listsub1['id']." ORDER BY cat_order ASC");
								while ($listsub2 = @mysql_fetch_array ($sub_cat2)){
									list($p_cat_chon2) = @mysql_fetch_array(@mysql_query("SELECT mod_name FROM w3style_modules WHERE id = ".$listsub2['cat_type']));
								$tpl->assign(
									array(
										'lscat_id2' => $listsub2['id'],
										'lscat_name2' => $listsub2['cat_name'],
										'lscat_desc2' => $listsub2['cat_info'],
										'lscat_stt2' => $listsub2['cat_order'],
										'lscat_type2' => $p_cat_chon2,
										'lscat_state2' => $listsub2['cat_home'],
										'lscat_state2_2' => ($listsub2['cat_home'] == 1)?$listsub2['cat_home'] = 0:$listsub2['cat_home'] = 1,
									));
									$tpl->parse('list_cat_sub2');
								}
						
							$tpl->assign(
								array(
									'lscat_id1' => $listsub1['id'],
									'lscat_name1' => $listsub1['cat_name'],
									'lscat_desc1' => $listsub1['cat_info'],
									'lscat_state1' => $listsub1['cat_home'],
									'lscat_type1' => $p_cat_chon1,
									'lscat_state1_1' => ($listsub1['cat_home'] == 1)?$listsub1['cat_home'] = 0:$listsub1['cat_home'] = 1,
									'lscat_stt1' => $listsub1['cat_order'],
								));
							$tpl->parse('list_cat_sub1');
						}
						$tpl->assign(
							array(
								'lscat_id' => $listsub['id'],
								'lscat_name' => $listsub['cat_name'],
								'lscat_desc' => $listsub['cat_info'],
								'lscat_state' => $listsub['cat_home'],
								'lscat_type' => $p_cat_chon,
								'lscat_state1' => ($listsub['cat_home'] == 1)?$listsub['cat_home'] = 0:$listsub['cat_home'] = 1,
								'lscat_stt' => $listsub['cat_order'],
							));
						$tpl->parse('list_cat_sub');
					}
					$tpl->assign(
						array(
							'lcat_id' => $lcat['id'],
							'lcat_name' => $lcat['cat_name'],
							'lcat_desc' => $lcat['cat_info'],
							'lcat_stt' => $lcat['cat_order'],
							'lcat_type' => $p_lcat_chon,
							'lcat_state' => $lcat['cat_home'],
							'lcat_state1' => ($lcat['cat_home'] == 1)?$lcat['cat_home'] = 0:$lcat['cat_home'] = 1,
						));
					$tpl->parse('list_cat');
				}  
				$this_menu .= ' | Danh mục';
				break;                    
			
				case '1':
					$this_menu .= ' | Danh sách Modules';
					$home_hide = @mysql_query("SELECT id, mod_name, mod_home FROM w3style_modules WHERE mod_home = 0");
					while ($hide = @mysql_fetch_array ($home_hide)){
						$tpl->assign(
							array(
								'mod_id' => $hide['id'],
								'mod_name' => $hide['mod_name'],
							));
						$tpl->parse('home_hide');
					}
					$home_show = @mysql_query("SELECT id, mod_name, mod_home FROM w3style_modules WHERE mod_home = 1");
					while ($show = @mysql_fetch_array ($home_show)){
					
					$tpl->assign(
							array(
								'mod_id' => $show['id'],
								'mod_name' => $show['mod_name'],
							));
						$tpl->parse('home_show');
					}			
				break;
				
				case '2':
					$this_menu .= ' | Danh mục hiển thị';				
				break;
			}
		break;
		
		case '2':
			$this_menu = '| Bài viết';
			switch($sub_menu) {
				case '0':
					$this_menu .= ' | Bài viết mới';	
					if($_GET['id'] > 0){
                        $post = @mysql_fetch_array(@mysql_query("SELECT * FROM w3style_posts WHERE post_type = 1 and id = ".$_GET['id']));
                        $file = explode(',',$post['post_file']);
                        array_shift($file);
                        $lfile = '';
                        foreach ($file as $item) {
                            $i ++;
                            $it = explode('|',$item);
                            $lfile .= '<p id="file'.$i.'">->'.$it[0].'<a onclick="$(\'#file'.$i.'\').remove();$(\'#filecontent > input\').val($(\'#filecontent > input\').val().replace(\','.$it[0].'|'.$it[1].'\',\'\'));" style="color: red; cursor: pointer;">X</a></p>';
                        }
                        $tpl->assign(
                            array(
                                'epost_action' => 'edit',
                                'epost_id' => $post['id'],
                                'epost_title' => $post['post_name'],
                                'epost_quote' => $post['post_quote'],
                                'epost_content' => $post['post_content'],
                                'epost_img' => $post['post_image'],
                                'epost_lfile' => $lfile,
                                'epost_file' => $post['post_file'],
                                'epost_show' => ($post['post_show']==1)?'checked=""':'',
                                'epost_bt' => 'Sửa',
                            ));
                    }
                    else {
                        $tpl->assign(
                            array(
                                'epost_action' => 'add',
                                'epost_id' => '',
                                'epost_title' => 'Gõ tiêu đề vào đây" onfocus="if(this.value==\'Gõ tiêu đề vào đây\')this.value=\'\'" onblur="if(this.value==\'\')this.value=\'Gõ tiêu đề vào đây\'',
                                'epost_quote' => '',
                                'epost_content' => '',
                                'epost_img' => '',
                                'epost_lfile' => '',
                                'epost_file' => '',
                                'epost_show' => 'checked=""',
                                'epost_bt' => 'Đăng bài',
                            ));
                    }
                
                    $showcat_post = get_option('showcat_post');
                    $cats = @mysql_query("SELECT id, cat_name FROM w3style_cats WHERE cat_sub = 0 and (cat_type IN (".$showcat_post.")) ORDER BY cat_order ASC");
                    list($pd_cat1) = @mysql_fetch_array(@mysql_query("SELECT post_cat FROM w3style_posts WHERE id = ".$_GET['id']));
                    while ($listcat = @mysql_fetch_array ($cats)){
                        
                        $sub_cat = @mysql_query("SELECT id, cat_name FROM w3style_cats WHERE cat_sub = ".$listcat['id']." ORDER BY cat_order ASC");
                        while ($listsub = @mysql_fetch_array ($sub_cat)){
                            
                             $sub_cat1 = @mysql_query("SELECT id, cat_name FROM w3style_cats WHERE cat_sub = ".$listsub['id']." ORDER BY cat_order ASC");
                                 while ($listsub1 = @mysql_fetch_array ($sub_cat1)){
                                    
                                    $sub_cat2 = @mysql_query("SELECT id, cat_name FROM w3style_cats WHERE cat_sub = ".$listsub1['id']." ORDER BY cat_order ASC");
                                               while ($listsub2 = @mysql_fetch_array ($sub_cat2)){
                                              $tpl->assign(
                                                     array(
                                                            'cat_id_sub2' => $listsub2['id'],
                                                            'cat_name_sub2' => $listsub2['cat_name'],
                                                            'ecat_check_sub2' => ($listsub2['id'] == $pd_cat1)?'selected':'',
                                                        ));
                                    $tpl->parse('p_cat_sub2');
                              }
                              
                                 $tpl->assign(
                                  array(
                                    'cat_id_sub1' => $listsub1['id'],
                                    'cat_name_sub1' => $listsub1['cat_name'],
                                    'ecat_check_sub1' => ($listsub1['id'] == $pd_cat1)?'selected':'',
                                    
                                ));
                                 $tpl->parse('p_cat_sub1');
                              }
                        
                            $tpl->assign(
                                array(
                                    'cat_id_sub' => $listsub['id'],
                                    'cat_name_sub' => $listsub['cat_name'],
                                    'ecat_check_sub' => ($listsub['id'] == $pd_cat1)?'selected':'',
                                    
                                ));
                            $tpl->parse('p_cat_sub');
                        }
                        $tpl->assign(
                            array(
                                'cat_id' => $listcat['id'],
                                'cat_name' => $listcat['cat_name'],
                                'ecat_check' => ($listcat['id'] == $pd_cat1)?'selected':'',
                            ));
                        $tpl->parse('p_cat');
                    }
				break;
				
				case '1':
					$current_page = ($_GET['page'])?$_GET['page']:1;
                    if($_GET['user']) {
                        $modpage = '&user='.$_GET['user'];
                        $p_where = 'and post_user = '.$_GET['user'];
                    }
                    elseif($_GET['cat']) {
                        $modpage = '&cat='.$_GET['cat'];
                        $p_where = 'and post_cat = '.$_GET['cat'];
                    }
                    else if(isset($_GET['name'])) {
                        $s_name = $_GET['name'];
                        $modpage = '&name='.$_GET['name'];
                        $p_where = 'and post_name LIKE "%'.$s_name.'%"';
                    }else {
                        $modpage = '';
                        $p_where = '';
                    }
                    $p_start = ($current_page -1) * get_option('paging');
                    $total_p = @mysql_num_rows(@mysql_query("SELECT id FROM w3style_posts WHERE post_type = 1 ".$p_where.""));
                    $post_list = @mysql_query("SELECT * FROM w3style_posts WHERE post_type = 1 ".$p_where." ORDER BY id DESC LIMIT ".$p_start.",".get_option('paging'));
                    while ($lpost = @mysql_fetch_array ($post_list)){
                        list($p_user) = @mysql_fetch_array(@mysql_query("SELECT user_nick FROM w3style_users WHERE id = ".$lpost['post_user']));
                        list($p_cat) = @mysql_fetch_array(@mysql_query("SELECT cat_name FROM w3style_cats WHERE id = ".$lpost['post_cat']));
                        $tpl->assign(
                            array(
                                'lpost_id' => $lpost['id'],
                                'lpost_name' => $lpost['post_name'],
                                'lpost_showcolor' => ($lpost['post_show'] == 0)?'#dbdbdb':'',
                                'lpost_hot' => $lpost['post_hot'],
                                'lpost_sukien' => $lpost['post_sukien'],
                                'lpost_show' => $lpost['post_show'],
                                'lpost_user' => $p_user,
                                'lpost_cat' => $p_cat,
                                'pu_id' => $lpost['post_user'],
                                'pc_id' => $lpost['post_cat'],
                                'lpost_hot1' => ($lpost['post_hot'] == 1)?$lpost['post_hot'] = 0:$lpost['post_hot'] = 1,
                                'lpost_show1' => ($lpost['post_show'] == 0)?$lpost['post_show'] = 1:$lpost['post_show'] = 0,
                                'lpost_sukien1' => ($lpost['post_sukien'] == 1)?$lpost['post_sukien'] = 0:$lpost['post_sukien'] = 1,
                                'lpost_time' => formatTime($lpost['post_time'], 2),
                            ));
                        $tpl->parse('post_list');
                    }
                    $_SESSION['link'] = $_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING'];
                    $tpl->assign('lp_paging',paging(get_option('paging'),$current_page, $total_p, 'index.php?m=2&sm=1',$modpage.'&page=' ,false));
                    $this_menu .= ' | Danh sách bài';
				break;
		}
		break;
		
		case '3':
			$this_menu = '| Video';
			switch($sub_menu) {
				case '0':
					$this_menu .= ' | Video mới';	
					if($_GET['id'] > 0){
                        $video = @mysql_fetch_array(@mysql_query("SELECT * FROM w3style_videos WHERE video_type = 1 and id = ".$_GET['id']));
                        $file = explode(',',$video['video_file']);
                        array_shift($file);
                        $lfile = '';
                        foreach ($file as $item) {
                            $i ++;
                            $it = explode('|',$item);
                            $lfile .= '<p id="file'.$i.'">->'.$it[0].'<a onclick="$(\'#file'.$i.'\').remove();$(\'#filecontent > input\').val($(\'#filecontent > input\').val().replace(\','.$it[0].'|'.$it[1].'\',\'\'));" style="color: red; cursor: pointer;">X</a></p>';
                        }
                        $tpl->assign(
                            array(
                                'evideo_action' => 'edit',
                                'evideo_id' => $video['id'],
                                'evideo_title' => $video['video_name'],
                                'evideo_quote' => $video['video_quote'],
					'evideo_link' => $video['video_link'],
                                'evideo_img' => $video['video_image'],
                                'evideo_lfile' => $lfile,
                                'evideo_file' => $video['video_file'],
                                'evideo_show' => ($video['video_show']==1)?'checked=""':'',
                                'evideo_bt' => 'Sửa',
                            ));
                    }
                    else {
                        $tpl->assign(
                            array(
                                'evideo_action' => 'add',
                                'evideo_id' => '',
                                'evideo_title' => 'Gõ tiêu đề vào đây" onfocus="if(this.value==\'Gõ tiêu đề vào đây\')this.value=\'\'" onblur="if(this.value==\'\')this.value=\'Gõ tiêu đề vào đây\'',
                                'evideo_quote' => '',
                                'evideo_link' => '',
                                'evideo_img' => '',
                                'evideo_lfile' => '',
                                'evideo_file' => '',
                                'evideo_show' => 'checked=""',
                                'evideo_bt' => 'Đăng bài',
                            ));
                    }
                
                    $showcat_video = get_option('showcat_video');
                    $cats = @mysql_query("SELECT id, cat_name FROM w3style_cats WHERE cat_sub = 0 and (cat_type IN (".$showcat_video.")) ORDER BY cat_order ASC");
                    list($pd_cat1) = @mysql_fetch_array(@mysql_query("SELECT video_cat FROM w3style_videos WHERE id = ".$_GET['id']));
                    while ($listcat = @mysql_fetch_array ($cats)){                        
                        $sub_cat = @mysql_query("SELECT id, cat_name FROM w3style_cats WHERE cat_sub = ".$listcat['id']." ORDER BY cat_order ASC");
                        while ($listsub = @mysql_fetch_array ($sub_cat)){
                            
                             $sub_cat1 = @mysql_query("SELECT id, cat_name FROM w3style_cats WHERE cat_sub = ".$listsub['id']." ORDER BY cat_order ASC");
                                 while ($listsub1 = @mysql_fetch_array ($sub_cat1)){
                                    
                                    $sub_cat2 = @mysql_query("SELECT id, cat_name FROM w3style_cats WHERE cat_sub = ".$listsub1['id']." ORDER BY cat_order ASC");
                                               while ($listsub2 = @mysql_fetch_array ($sub_cat2)){
                                              $tpl->assign(
                                                     array(
                                                            'catvideo_id_sub2' => $listsub2['id'],
                                                            'catvideo_name_sub2' => $listsub2['cat_name'],
                                                            'ecatvideo_check_sub2' => ($listsub2['id'] == $pd_cat1)?'selected':'',
                                                        ));
                                    $tpl->parse('p_catvideo_sub2');
                              }
                              
                                 $tpl->assign(
                                  array(
                                    'catvideo_id_sub1' => $listsub1['id'],
                                    'catvideo_name_sub1' => $listsub1['cat_name'],
                                    'ecatvideo_check_sub1' => ($listsub1['id'] == $pd_cat1)?'selected':'',
                                    
                                ));
                                 $tpl->parse('p_catvideo_sub1');
                              }
                        
                            $tpl->assign(
                                array(
                                    'catvideo_id_sub' => $listsub['id'],
                                    'catvideo_name_sub' => $listsub['cat_name'],
                                    'ecatvideo_check_sub' => ($listsub['id'] == $pd_cat1)?'selected':'',
                                    
                                ));
                            $tpl->parse('p_catvideo_sub');
                        }
                        $tpl->assign(
                            array(
                                'catvideo_id' => $listcat['id'],
                                'catvideo_name' => $listcat['cat_name'],
                                'ecatvideo_check' => ($listcat['id'] == $pd_cat1)?'selected':'',
                            ));
                        $tpl->parse('p_catvideo');
                    }
				break;
						
				case '1':
					$current_page = ($_GET['page'])?$_GET['page']:1;
					if($_GET['user']) {
						$modpage = '&user='.$_GET['user'];
						$p_where = 'and video_user = '.$_GET['user'];
					}
					elseif($_GET['cat']) {
						$modpage = '&cat='.$_GET['cat'];
						$p_where = 'and video_cat = '.$_GET['cat'];
					}
					else if(isset($_GET['name'])) {
						$s_name = $_GET['name'];
						$modpage = '&name='.$_GET['name'];
						$p_where = 'and video_name LIKE "%'.$s_name.'%"';
					}else {
						$modpage = '';
						$p_where = '';
					}
					$p_start = ($current_page -1) * get_option('paging');
					$total_p = @mysql_num_rows(@mysql_query("SELECT id FROM w3style_videos WHERE video_type = 1 ".$p_where.""));
					$video_list = @mysql_query("SELECT * FROM w3style_videos WHERE video_type = 1 ".$p_where." ORDER BY id DESC LIMIT ".$p_start.",".get_option('paging'));
					while ($lvideo = @mysql_fetch_array ($video_list)){
						list($p_user) = @mysql_fetch_array(@mysql_query("SELECT user_nick FROM w3style_users WHERE id = ".$lvideo['video_user']));
						list($p_cat) = @mysql_fetch_array(@mysql_query("SELECT cat_name FROM w3style_cats WHERE id = ".$lvideo['video_cat']));
						$tpl->assign(
							array(
								'lvideo_id' => $lvideo['id'],
								'lvideo_name' => $lvideo['video_name'],
								'lvideo_showcolor' => ($lvideo['video_show'] == 0)?'#dbdbdb':'',
								'lvideo_hot' => $lvideo['video_hot'],
								'lvideo_sukien' => $lvideo['video_sukien'],
								'lvideo_show' => $lvideo['video_show'],
								'lvideo_user' => $p_user,
								'lvideo_cat' => $p_cat,
								'pu_id' => $lvideo['video_user'],
								'pc_id' => $lvideo['video_cat'],
								'lvideo_hot1' => ($lvideo['video_hot'] == 1)?$lvideo['video_hot'] = 0:$lvideo['video_hot'] = 1,
								'lvideo_show1' => ($lvideo['video_show'] == 0)?$lvideo['video_show'] = 1:$lvideo['video_show'] = 0,
								'lvideo_sukien1' => ($lvideo['video_sukien'] == 1)?$lvideo['video_sukien'] = 0:$lvideo['video_sukien'] = 1,
								'lvideo_time' => formatTime($lvideo['video_time'], 2),
							));
						$tpl->parse('video_list');
					}
					$_SESSION['link'] = $_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING'];
					$tpl->assign('lp_paging',paging(get_option('paging'),$current_page, $total_p, 'index.php?m=2&sm=1',$modpage.'&page=' ,false));
					$this_menu .= ' | Danh sách bài';
				break;
			}
		break;
		
		case '4':
			$this_menu = '| Album ảnh';
			switch($sub_menu) {
				case '0':
					$this_menu .= ' | Album ảnh mới';	
					if($_GET['id'] > 0){
                        $al_post = @mysql_fetch_array(@mysql_query("SELECT * FROM w3style_album WHERE id = ".$_GET['id']));
                        
                        $tpl->assign(
                            array(
                                'album_action' => 'edit',
                                'lalbum_id' => $al_post['id'],
                                'album_title' => $al_post['album_name'],
                                'album_quote' => '',
                                'album_img' => $al_post['album_image'],
								'attach_image_urls' => $al_post['attach_image'],
                                'album_bt' => 'Sửa Album',
                            ));
                    }
                    else {
                        $tpl->assign(
                            array(
                                'album_action' => 'add',
                                'album_id' => '',
                                'album_title' => 'Gõ tiêu đề vào đây" onfocus="if(this.value==\'Gõ tiêu đề vào đây\')this.value=\'\'" onblur="if(this.value==\'\')this.value=\'Gõ tiêu đề vào đây\'',
                                'album_quote' => '',
                                'album_img' => '',
								'attach_image_urls' => '',
                                'album_bt' => 'Đăng Album',
                            ));
                    }
                
                
                    $al_cats = @mysql_query("SELECT id, cat_name FROM w3style_cats WHERE cat_sub = 0 and cat_type = '3' ORDER BY cat_order ASC");
                    list($al_cat1) = @mysql_fetch_array(@mysql_query("SELECT album_cat FROM w3style_album WHERE id = ".$_GET['id']));
                    while ($list_al1 = @mysql_fetch_array ($al_cats)){
                        
                        $sub_album2 = @mysql_query("SELECT id, cat_name FROM w3style_cats WHERE cat_sub = ".$list_al1['id']." ORDER BY cat_order ASC");
                        while ($list_al2 = @mysql_fetch_array ($sub_album2)){
                            
                             $sub_album3 = @mysql_query("SELECT id, cat_name FROM w3style_cats WHERE cat_sub = ".$list_al2['id']." ORDER BY cat_order ASC");
                                 while ($list_al3 = @mysql_fetch_array ($sub_album3)){
                                    
                                    $sub_album4 = @mysql_query("SELECT id, cat_name FROM w3style_cats WHERE cat_sub = ".$list_al3['id']." ORDER BY cat_order ASC");
                                               while ($list_al4 = @mysql_fetch_array ($sub_album4)){
                                              $tpl->assign(
                                                     array(
                                                            'album_id4' => $list_al4['id'],
                                                            'album_name4' => $list_al4['cat_name'],
                                                            'album_check4' => ($list_al4['id'] == $al_cat1)?'selected':'',
                                                        ));
                                    $tpl->parse('album_cat4');
                              }
                              
                                 $tpl->assign(
                                  array(
                                    'album_id3' => $list_al3['id'],
                                    'album_name3' => $list_al3['cat_name'],
                                    'album_check3' => ($list_al3['id'] == $al_cat1)?'selected':'',
                                    
                                ));
                                 $tpl->parse('album_cat3');
                              }
                        
                            $tpl->assign(
                                array(
                                    'album_id2' => $list_al2['id'],
                                    'album_name2' => $list_al2['cat_name'],
                                    'album_check2' => ($list_al2['id'] == $al_cat1)?'selected':'',
                                    
                                ));
                            $tpl->parse('album_cat2');
                        }
                        
                        $tpl->assign(
                            array(
                                'album_id' => $list_al1['id'],
                                'album_name' => $list_al1['cat_name'],
                                'album_check' => ($list_al1['id'] == $al_cat1)?'selected':'',
                            ));
                        $tpl->parse('album_cat');
						
						$listImages = explode(',', $al_post['attach_image']);
		
						foreach($listImages as $imgUrl){
							if($imgUrl){
								$thumb = explode('/', $imgUrl);
								$thumb[count($thumb) - 1] = 'thumbs-' . $thumb[count($thumb) - 1];
								
								$tpl->assign(
									array(
										'attach_image_url' => $imgUrl,
										'attach_thumb_url' => implode('/', $thumb)
									)
									
								);
								$tpl->parse('album_images');                    		
							}
						}
                    }
				break;
					
			case '1':
				$this_menu .= ' | Danh sách album';	
				 $current_page = ($_GET['page'])?$_GET['page']:1;
                    if($_GET['cat']) {
                        $modpage = '&cat='.$_GET['cat'];
                        $p_where = 'WHERE album_cat = '.$_GET['cat'];
                    }
                    else {
                        $modpage = '';
                        $p_where = '';
                    }
                    $p_start = ($current_page -1) * get_option('paging');
                    $total_p = @mysql_num_rows(@mysql_query("SELECT id FROM w3style_album ".$p_where.""));
                    $post_album = @mysql_query("SELECT * FROM w3style_album ".$p_where." ORDER BY id DESC LIMIT ".$p_start.",".get_option('paging'));
                    while ($lpost_album = @mysql_fetch_array ($post_album)){
                        list($p_cat) = @mysql_fetch_array(@mysql_query("SELECT cat_name FROM w3style_cats WHERE id = ".$lpost_album['album_cat']));
                        $tpl->assign(
                            array(
                                'lalbum_id' => $lpost_album['id'],
                                'lalbum_name' => $lpost_album['album_name'],
                                'lalbum_cat' => $p_cat,
                                'lalbum_image' => $lpost_album['album_image'],
                                'lalbum_fullimg' => $lpost_album['album_fullimg'],
                                'lalbum_hot' => $lpost_album['album_hot'],
                                'lalbum_show' => $lpost_album['album_show'],
								'lalbum_showcolor' => ($lpost_album['album_show'] == 0)?'#dbdbdb':'',
                                'pc_id' => $lpost_album['post_cat'],
                                'lalbum_time' => formatTime($lpost_album['album_time'], 2),
                                'lalbum_hot1' => ($lpost_album['album_hot'] == 1)?$lpost_album['album_hot'] = 0:$lpost_album['album_hot'] = 1,
                                'lalbum_show1' => ($lpost_album['album_show'] == 0)?$lpost_album['album_show'] = 1:$lpost_album['album_show'] = 0,
                            ));
                        $tpl->parse('album_list');
                    }
                    $_SESSION['link'] = $_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING'];
                    $tpl->assign('lp_paging',paging(get_option('paging'),$current_page, $total_p, 'index.php?m=17',$modpage.'&page=' ,false));
			break;
			}
			
			case '5':
			$this_menu = '| Sản phẩm';
			switch($sub_menu) {
			case '0':
				if($_GET['id'] > 0){
					unset($_SESSION['cat']); 
					$product = @mysql_fetch_array(@mysql_query("SELECT * FROM w3style_products WHERE id = ".$_GET['id']));
					$descrip = explode(' .|~|. ',$product['product_descrip']);						
					$dr[1] = array(
						'key' => '',
						'val' => '',
					);
					$dr[2] = array(
						'show' => 'display: none;',
						'key' => '',
						'val' => '',
					);
					$dr[3] = array(
						'show' => 'display: none;',
						'key' => '',
						'val' => '',
					);
					$dr[4] = array(
						'show' => 'display: none;',
						'key' => '',
						'val' => '',
					);
					$dr[5] = array(
						'show' => 'display: none;',
						'key' => '',
						'val' => '',
					);
					$dr[6] = array(
						'show' => 'display: none;',
						'key' => '',
						'val' => '',
					);
					$dr[7] = array(
						'show' => 'display: none;',
						'key' => '',
						'val' => '',
					);
					$dr[8] = array(
						'show' => 'display: none;',
						'key' => '',
						'val' => '',
					);
					$dr[9] = array(
						'show' => 'display: none;',
						'key' => '',
						'val' => '',
					);
					$dr[10] = array(
						'show' => 'display: none;',
						'key' => '',
						'val' => '',
					);
					$dr[11] = array(
						'show' => 'display: none;',
						'key' => '',
						'val' => '',
					);
					$dr[12] = array(
						'show' => 'display: none;',
						'key' => '',
						'val' => '',
					);
					$dr[13] = array(
						'show' => 'display: none;',
						'key' => '',
						'val' => '',
					);
					$dr[14] = array(
						'show' => 'display: none;',
						'key' => '',
						'val' => '',
					);
					$dr[15] = array(
						'show' => 'display: none;',
						'key' => '',
						'val' => '',
					);
					if(!$descrip)$dr_total = 1;
					else {
						foreach ($descrip as $item) {
							$dr_total ++;
							$it = explode(': ',$item);
							$dr[$dr_total] = array(
								'show' => '',
								'key' => $it[0],
								'val' => $it[1],
							);
						}
					}
					$tpl->assign(
						array(
							
							'eproduct_action' => 'edit',
							'eproduct_id' => $product['id'],
							'eproduct_title' => stripslashes($product['product_name']),
							'eproduct_content' => $product['product_info'],
							'eproduct_code' => $product['product_code'],
							'eproduct_km' => $product['product_km'],
							'eproduct_price' => $product['product_price'],
							'eproduct_free' => $product['product_free'],
							'eproduct_total' => $product['product_total'],
							'eproduct_quality' => $product['product_quality'],
							'eproduct_warranty' => $product['product_warranty'],
							'eproduct_img' => $product['product_image'],
							'eproduct_quote' => $product['product_quote'],
							'descrip_total' => $dr_total,
							'attach_image_urls' => $product['attach_image'],
							'dr1_a' => $dr[1]['key'],
							'dr1_b' => $dr[1]['val'],
							'dr2_d' => $dr[2]['show'],
							'dr2_a' => $dr[2]['key'],
							'dr2_b' => $dr[2]['val'],
							'dr3_d' => $dr[3]['show'],
							'dr3_a' => $dr[3]['key'],
							'dr3_b' => $dr[3]['val'],
							'dr4_d' => $dr[4]['show'],
							'dr4_a' => $dr[4]['key'],
							'dr4_b' => $dr[4]['val'],
							'dr5_d' => $dr[5]['show'],
							'dr5_a' => $dr[5]['key'],
							'dr5_b' => $dr[5]['val'],
							'dr6_d' => $dr[6]['show'],
							'dr6_a' => $dr[6]['key'],
							'dr6_b' => $dr[6]['val'],
							'dr7_d' => $dr[7]['show'],
							'dr7_a' => $dr[7]['key'],
							'dr7_b' => $dr[7]['val'],
							'dr8_d' => $dr[8]['show'],
							'dr8_a' => $dr[8]['key'],
							'dr8_b' => $dr[8]['val'],
							'dr9_d' => $dr[9]['show'],
							'dr9_a' => $dr[9]['key'],
							'dr9_b' => $dr[9]['val'],
							'dr10_d' => $dr[10]['show'],
							'dr10_a' => $dr[10]['key'],
							'dr10_b' => $dr[10]['val'],
							'dr11_d' => $dr[11]['show'],
							'dr11_a' => $dr[11]['key'],
							'dr11_b' => $dr[11]['val'],
							'dr12_d' => $dr[12]['show'],
							'dr12_a' => $dr[12]['key'],
							'dr12_b' => $dr[12]['val'],
							'dr13_d' => $dr[13]['show'],
							'dr13_a' => $dr[13]['key'],
							'dr13_b' => $dr[13]['val'],
							'dr14_d' => $dr[14]['show'],
							'dr14_a' => $dr[14]['key'],
							'dr14_b' => $dr[14]['val'],
							'dr15_d' => $dr[15]['show'],
							'dr15_a' => $dr[15]['key'],
							'dr15_b' => $dr[15]['val'],
							'eproduct_bt' => 'Cập nhật',
						));
				}
				else {

					$tpl->assign(
						array(
							'eproduct_action' => 'add',
							'eproduct_id' => '',
							'eproduct_title' => 'Gõ tên SP vào đây" onfocus="if(this.value==\'Gõ tên SP vào đây\')this.value=\'\'" onblur="if(this.value==\'\')this.value=\'Gõ tên SP vào đây\'',
							'eproduct_content' => ' ',
							'eproduct_code' => 'MS',
							'eproduct_km' => '',
							'eproduct_price' => '0',
							'eproduct_free' => '0',
							'eproduct_total' => '0',
							'eproduct_quality' => 'Mới',
							'eproduct_warranty' => '0',
							'eproduct_img' => '',
							'descrip_total' => '1',
							'eproduct_quote' => '',
							'attach_image_urls' => '',
							'dr1_a' => '',
							'dr1_b' => '',
							'dr2_d' => 'display: none;',
							'dr2_a' => '',
							'dr2_b' => '',
							'dr3_d' => 'display: none;',
							'dr3_a' => '',
							'dr3_b' => '',
							'dr4_d' => 'display: none;',
							'dr4_a' => '',
							'dr4_b' => '',
							'dr5_d' => 'display: none;',
							'dr5_a' => '',
							'dr5_b' => '',
							'dr6_d' => 'display: none;',
							'dr6_a' => '',
							'dr6_b' => '',
							'dr7_d' => 'display: none;',
							'dr7_a' => '',
							'dr7_b' => '',
							'dr8_d' => 'display: none;',
							'dr8_a' => '',
							'dr8_b' => '',
							'dr9_d' => 'display: none;',
							'dr9_a' => '',
							'dr9_b' => '',
							'dr10_d' => 'display: none;',
							'dr10_a' => '',
							'dr10_b' => '',
							'dr11_d' => 'display: none;',
							'dr11_a' => '',
							'dr11_b' => '',
							'dr12_d' => 'display: none;',
							'dr12_a' => '',
							'dr12_b' => '',
							'dr13_d' => 'display: none;',
							'dr13_a' => '',
							'dr13_b' => '',
							'dr14_d' => 'display: none;',
							'dr14_a' => '',
							'dr14_b' => '',
							'dr15_d' => 'display: none;',
							'dr15_a' => '',
							'dr15_b' => '',
							'eproduct_bt' => 'Thêm sản phẩm',
						));
				}
			
			
				$cats = @mysql_query("SELECT id, cat_name FROM w3style_cats WHERE cat_sub = 0 and (cat_type IN (1)) ORDER BY cat_order ASC");    
				while ($listcat = @mysql_fetch_array ($cats)){
					$sub_cat = @mysql_query("SELECT id, cat_name FROM w3style_cats WHERE cat_sub = ".$listcat['id']." ORDER BY cat_order ASC");
					while ($listsub = @mysql_fetch_array ($sub_cat)){
						
						$sub_cat1 = @mysql_query("SELECT id, cat_name FROM w3style_cats WHERE cat_sub = ".$listsub['id']." ORDER BY cat_order ASC");
							while ($listsub1 = @mysql_fetch_array ($sub_cat1)){
								
								$sub_cat2 = @mysql_query("SELECT id, cat_name FROM w3style_cats WHERE cat_sub = ".$listsub1['id']." ORDER BY cat_order ASC");
									while ($listsub2 = @mysql_fetch_array ($sub_cat2)){
									 $tpl->assign(
										array(
										'cat_id_sub2' => $listsub2['id'],
										'cat_name_sub2' => $listsub2['cat_name'],
										'cat_check2' => (($listsub2['id'] == $product['product_cat']) || ($listsub2['id'] == $_SESSION['cat']) )?'selected=""':'',
									));
								$tpl->parse('pd_cat_sub2');
						}
						
								$tpl->assign(
								array(
									'cat_id_sub1' => $listsub1['id'],
									'cat_name_sub1' => $listsub1['cat_name'],
									'cat_check1' => (($listsub1['id'] == $product['product_cat']) || ($listsub1['id'] == $_SESSION['cat']) )?'selected=""':'',
								));
							$tpl->parse('pd_cat_sub1');
						}
					
						$tpl->assign(
							array(
								'cat_id_sub' => $listsub['id'],
								'cat_name_sub' => $listsub['cat_name'],
								'cat_check' => (($listsub['id'] == $product['product_cat']) || ($listsub['id'] == $_SESSION['cat']) )?'selected=""':'',
							));
						$tpl->parse('pd_cat_sub');
					}
					$tpl->assign(
						array(
							'cat_id' => $listcat['id'],
							'cat_name' => $listcat['cat_name'],
							'catcheck' => (($listcat['id'] == $product['product_cat']) || ($listcat['id'] == $_SESSION['cat']) )?'selected=""':'',
						));
					$tpl->parse('pd_cat');
				}
				$listImages = explode(',', $product['attach_image']);

				foreach($listImages as $imgUrl){
					if($imgUrl){
						$thumb = explode('/', $imgUrl);
						$thumb[count($thumb) - 1] = 'thumbs-' . $thumb[count($thumb) - 1];
						
						$tpl->assign(
							array(
								'attach_image_url' => $imgUrl,
								'attach_thumb_url' => implode('/', $thumb)
							)
							
						);
						$tpl->parse('pd_images');                    		
					}
				}
				
				$this_menu .= ' | Thêm sản phẩm';
			break;
					
			case '1':
				$current_page = ($_GET['page'])?$_GET['page']:1;
				if($_GET['cat']) {
					$modpage = '&cat='.$_GET['cat'];
					$pd_where = 'WHERE product_cat = '.$_GET['cat'];
				}
				else if(isset($_GET['name'])) {
					$s_name = $_GET['name'];
					$modpage = '&name='.$_GET['name'];
					$pd_where = 'WHERE product_name LIKE "%'.$s_name.'%"';
				}else {
					$modpage = '';
					$pd_where = '';
				}
				$pd_start = ($current_page -1) * get_option('paging');
				$total_pd = @mysql_num_rows(@mysql_query("SELECT id FROM w3style_products ".$pd_where.""));
				$product_list = @mysql_query("SELECT * FROM w3style_products ".$pd_where." ORDER BY id DESC LIMIT ".$pd_start.",".get_option('paging'));
				while ($lproduct = @mysql_fetch_array ($product_list)){
					list($pd_cat) = @mysql_fetch_array(@mysql_query("SELECT cat_name FROM w3style_cats WHERE id = ".$lproduct['product_cat']));
					$tpl->assign(
						array(
							'lproduct_id' => $lproduct['id'],
							'lproduct_name' => $lproduct['product_name'],
							'lproduct_code' => $lproduct['product_code'],
							'lproduct_price' => number($lproduct['product_price']),
							'lproduct_showcolor' => ($lproduct['product_show'] == 0)?'#dbdbdb':'',
							'lproduct_free' => ($lproduct['product_free'])?number($lproduct['product_free']).' VNĐ':'Không',
							'lproduct_total' => number($lproduct['product_total']),
							'lproduct_cat' => $pd_cat,
							'pdc_id' => $lproduct['product_cat'],
							'lproduct_hot' => $lproduct['product_hot'],
							'lproduct_show' => $lproduct['product_show'],
							'lproduct_hot1' => ($lproduct['product_hot'] == 1)?$lproduct['product_hot'] = 0:$lproduct['product_hot'] = 1,
							'lproduct_show1' => ($lproduct['product_show'] == 1)?$lproduct['product_show'] = 0:$lproduct['product_show'] = 1,
							'lproduct_km' => ($lproduct['product_km'] <> NULL)?'<img src=templates/assets/img/icon_km.gif>':'',
						));
					$tpl->parse('product_list');
				}
				$_SESSION['link'] = $_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING'];
				$tpl->assign('lpd_paging',paging(get_option('paging'),$current_page, $total_pd, 'index.php?m=3',$modpage.'&page=' ,false));
				$this_menu .= ' | Danh sách';
			break;
			}
		break;
		
		case '6':
			$this_menu = '| Thành viên';
			switch($sub_menu) {
			case '0':
				for($i = 1; $i <= 31; $i ++){
					$tpl->assign(
						array(
							'dd' => $i,
						));
					$tpl->parse('list_dd2');
				}    
				for($i = 1; $i <= 12; $i ++){
					$tpl->assign(
						array(
							'mm' => $i,
						));
					$tpl->parse('list_mm2');
				}    
				for($i = 1900; $i <= 2014; $i ++){
					$tpl->assign(
						array(
							'yyyy' => $i,
						));
					$tpl->parse('list_yyyy2');
				}
				$this_menu .= ' | Thêm thành viên';
			break;
					
			case '1':				
				$current_page = ($_GET['page'])?$_GET['page']:1;
				$u_start = ($current_page -1) * get_option('paging');
				$total_u = @mysql_num_rows(@mysql_query("SELECT id FROM w3style_users"));
				$user_list = @mysql_query("SELECT id, user_nick, user_email, user_fullname, user_level FROM w3style_users ".$u_where." ORDER BY id DESC LIMIT ".$u_start.",".get_option('paging'));
				while ($luser = @mysql_fetch_array ($user_list)){				
					list($u_class) = @mysql_fetch_array(@mysql_query("SELECT class_name FROM w3style_class WHERE id = ".$luser['user_class']));
					if($luser['user_level'] <= 1) $tpl->parse('not_userid');
					$tpl->assign(
						array(
							'luser_id' => $luser['id'],
							'luser_nick' => $luser['user_nick'],
							'luser_name' => $luser['user_fullname'],
							'luser_email' => $luser['user_email'],
							'luser_level' => level($luser['user_level']),
						));
					$tpl->parse('list_user');
				}
				$tpl->assign('lu_paging',paging(get_option('paging'),$current_page, $total_u, 'index.php?m=10',$modpage.'&page=' ,false));
				$this_menu .= ' | Danh sách';
			break;
			
			case '2':
				$euser = @mysql_fetch_array(@mysql_query("SELECT * FROM w3style_users WHERE id = ".$_GET['id']));
				$tpl->assign(
					array(
						'my_id' => $_GET['id'],
						'my_nick' => $euser['user_nick'],
						'my_salt' => $euser['user_salt'],
						'my_name' => $euser['user_fullname'],
						'my_email' => $euser['user_email'],
						'my_sex1' => ($euser['user_sex'] == 1)?'selected=""':'',
						'my_sex2' => ($euser['user_sex'] == 2)?'selected=""':'',
						'my_info' => $euser['user_info'],
					));
				$birthday = birthday($euser['user_birthday']);
				for($i = 1; $i <= 31; $i ++){
					$tpl->assign(
						array(
							'dd' => $i,
							'my_dd' => ($i == $birthday['d'])?'selected=""':'',
						));
					$tpl->parse('list_dd4');
				}    
				for($i = 1; $i <= 12; $i ++){
					$tpl->assign(
						array(
							'mm' => $i,
							'my_mm' => ($i == $birthday['m'])?'selected=""':'',
						));
					$tpl->parse('list_mm4');
				}    
				for($i = 1940; $i <= 2010; $i ++){
					$tpl->assign(
						array(
							'yyyy' => $i,
							'my_yyyy' => ($i == $birthday['y'])?'selected=""':'',
						));
					$tpl->parse('list_yyyy4');
				}				  
				for($i = 0; $i <= 9; $i ++){
					if($i == 5) $i = 9;
					$tpl->assign(
						array(
							'level_id' => $i,
							'level_name' => level($i),
							'my_level' => ($i == $euser['user_level'])?'selected=""':'',
						));
					$tpl->parse('list_level');
				}
				
			break;
			}
		break;
		
		case '7':
			$this_menu = '| Chức năng khác';
			switch($sub_menu) {
			case '0':
				$current_page = ($_GET['page'])?$_GET['page']:1;
				if($_GET['type'] == 'media') {
					$modpage = '&type=media';
					$d_where = 'WHERE data_type = 2';
					$tpl->assign('media_curent','font-weight: bold;');
					$this_menu .= ' | Media';
				}
				elseif($_GET['type'] == 'other') {
					$modpage = '&type=other';
					$d_where = 'WHERE data_type = 3';
					$tpl->assign('other_curent','font-weight: bold;');
					$this_menu .= ' | Other';
				}
				else {
					$modpage = '';
					$d_where = 'WHERE data_type = 1';
					$tpl->assign('img_curent','font-weight: bold;');
					$this_menu .= ' | Ảnh';
				}
				$tpl->assign(
					array(
						'img_total' => @mysql_num_rows(@mysql_query("SELECT id FROM w3style_datas WHERE data_type = 1")),
						'media_total' => @mysql_num_rows(@mysql_query("SELECT id FROM w3style_datas WHERE data_type = 2")),
						'other_total' => @mysql_num_rows(@mysql_query("SELECT id FROM w3style_datas WHERE data_type = 3")),
					));
				$d_start = ($current_page -1) * get_option('paging');
				$total_d = @mysql_num_rows(@mysql_query("SELECT id FROM w3style_datas ".$d_where.""));
				$data_list = @mysql_query("SELECT * FROM w3style_datas ".$d_where." ORDER BY id DESC LIMIT ".$d_start.",".get_option('paging'));
				while ($ldata = @mysql_fetch_array ($data_list)){
					 $icon = ($ldata['data_type'] == 1)?$ldata['data_thumb']:'../data/javascripts/editor/icons/'.type($ldata['data_url']).'.png';
					$tpl->assign(
						array(
							'file_id' => $ldata['id'],
							'file_name' => $ldata['data_name'],
							'file_icon' => $icon,
							'file_desc' => $ldata['data_info'],
							'file_time' => formatTime($ldata['data_time'], 1),
						));
					$tpl->parse('file_list');
				}
				$_SESSION['link'] = $_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING'];
				$tpl->assign('ld_paging',paging(get_option('paging'),$current_page, $total_d, 'index.php?m=5',$modpage.'&page=' ,false));
				$this_menu .= ' | File đính kèm';
			break;
					
			case '1':		
				if($_GET['id'] > 0){
					$ad = @mysql_fetch_array(@mysql_query("SELECT * FROM w3style_ads WHERE id = ".$_GET['id']));
					$tpl->assign(
						array(
							'ead_action' => 'edit',
							'ead_id' => $ad['id'],
							'ead_name' => $ad['ad_name'],
							'ead_img' => $ad['ad_image'],
							'ead_url' => $ad['ad_link'],
							'ead_type1' => ($ad['ad_type'] == 1)?'selected=""':'',
							'ead_type2' => ($ad['ad_type'] == 2)?'selected=""':'',
							'ead_type3' => ($ad['ad_type'] == 3)?'selected=""':'',
							'ead_type4' => ($ad['ad_type'] == 4)?'selected=""':'',
							'ead_type5' => ($ad['ad_type'] == 5)?'selected=""':'',
							'ead_bt' => 'Sửa',
						));
					$this_menu .= ' | Sửa';
				}
				else {
					$tpl->assign(
						array(
							'ead_action' => 'add',
							'ead_id' => '',
							'ead_name' => '',
							'ead_img' => '',
							'ead_url' => 'http://',
							'ead_type1' => '',
							'ead_type2' => '',
							'ead_type3' => '',
							'ead_type4' => '',
							'ead_type5' => '',
							'ead_bt' => 'Thêm',
						));
				}
				
				
				$ad_list = @mysql_query("SELECT * FROM w3style_ads ORDER BY id DESC");
				while ($lad = @mysql_fetch_array ($ad_list)){
					switch($lad['ad_type']){
						case '1':
							$type = 'Header';
							break;
						case '2':
							$type = 'Footer';
							break;
						case '3':
							$type = 'Left';
							break;
						case '4':
							$type = 'Right';
							break;
						case '5':
							$type = 'Other';
					break;
					}
					$tpl->assign(
						array(
							'lad_id' => $lad['id'],
							'lad_showcolor' => ($lad['ad_home'] == 0)?'#dbdbdb':'',
							'lad_name' => $lad['ad_name'],
							'lad_img' => $lad['ad_image'],
							'lad_url' => $lad['ad_link'],
							'lad_type' => $type,
							'lad_home' => $lad['ad_home'],
							'lad_home1' => ($lad['ad_home'] == 1)?$lad['ad_home'] = 0:$lad['ad_home'] = 1,
						));
					$tpl->parse('list_ad');
				}
				$this_menu .= ' | Quảng cáo';
			break;
			
			case '2':				
				if($_GET['id'] > 0){
					$support = @mysql_fetch_array(@mysql_query("SELECT * FROM w3style_supports WHERE id = ".$_GET['id']));
					$tpl->assign(
						array(
							'esupport_action' => 'edit',
							'esupport_id' => $support['id'],
							'esupport_name' => $support['support_name'],
							'esupport_mobile' => $support['support_mobile'],
							'esupport_yahoo' => $support['support_yahoo'],
							'esupport_skype' => $support['support_skype'],
							'esupport_email' => $support['support_email'],
							'esupport_bt' => 'Sửa',
						));
					$this_menu .= ' | Sửa';
				}
				else {
					$tpl->assign(
						array(
							'esupport_action' => 'add',
							'esupport_id' => '',
							'esupport_name' => '',
							'esupport_mobile' => '',
							'esupport_yahoo' => '',
							'esupport_skype' => '',
							'esupport_email' => '',
							'esupport_bt' => 'Thêm',
						));
				}
				
				
				$support_list = @mysql_query("SELECT * FROM w3style_supports ORDER BY support_order ASC");
				while ($lsupport = @mysql_fetch_array ($support_list)){
					$tpl->assign(
						array(
							'lsupport_stt' => $lsupport['support_order'],
							'lsupport_id' => $lsupport['id'],
							'lsupport_name' => $lsupport['support_name'],
							'lsupport_mobile' => $lsupport['support_mobile'],
							'lsupport_yahoo' => $lsupport['support_yahoo'],
						));
					$tpl->parse('list_support');
				}
				$this_menu .= ' | Hỗ trợ online';
			break;
			
			case '3':
				$contact_list = @mysql_query("SELECT * FROM w3style_contacts ORDER BY id DESC");
				while ($lcontact = @mysql_fetch_array ($contact_list)){
					$tpl->assign(
						array(
							'lcontact_id' => $lcontact['id'],
							'lcontact_name' => $lcontact['contact_name'],
							'lcontact_title' => $lcontact['contact_title'],
							'lcontact_read1' => ($lcontact['contact_read'] == 1)?'':'font-weight: bold;',
							'lcontact_time' => formatTime($lcontact['contact_time'], 1),
						));
					$tpl->parse('list_contact');
				}
				$this_menu .= ' | Liên hệ';
			break;
			
			case '4':				
				if($_GET['id'] > 0){
					$slide = @mysql_fetch_array(@mysql_query("SELECT * FROM w3style_slides WHERE id = ".$_GET['id']));
					$tpl->assign(
						array(
							'eslide_action' => 'edit',
							'eslide_id' => $slide['id'],
							'eslide_name' => $slide['slide_name'],
							'eslide_content' => $slide['slide_content'],
							'eslide_img' => $slide['slide_img'],
							'eslide_url' => $slide['slide_url'],
							'eslide_bt' => 'Sửa',
						));
					$this_menu .= ' | Sửa';
				}
				else {
					$tpl->assign(
						array(
							'eslide_action' => 'add',
							'eslide_id' => '',
							'eslide_name' => '',
							'eslide_content' => '',
							'eslide_img' => '',
							'eslide_url' => 'http://',
							'eslide_bt' => 'Thêm',
						));
				}
				
				$s_list = @mysql_query("SELECT * FROM w3style_slides ORDER BY slide_order ASC");
				while ($lslide = @mysql_fetch_array ($s_list)){
					$tpl->assign(
						array(
							'lslide_id' => $lslide['id'],
							'lslide_order' => $lslide['slide_order'],
							'lslide_name' => $lslide['slide_name'],
							'lslide_img' => $lslide['slide_img'],
							'lslide_url' => $lslide['slide_url'],
						));
					$tpl->parse('list_slide');
				}
				$this_menu .= ' | Slide';
			break;
				
			case '5':
				@mysql_query("UPDATE w3style_contacts SET contact_read = '1' WHERE id = ".$_GET['id']);
				$contact = @mysql_fetch_array(@mysql_query("SELECT * FROM w3style_contacts WHERE id = ".$_GET['id']));
				$tpl->assign(
					array(
						'contact_id' => $_GET['id'],
						'contact_title' => $contact['contact_title'],
						'contact_name' => $contact['contact_name'],
						'contact_phone' => $contact['contact_phone'],
						'contact_fax' => ($contact['contact_fax'])?$contact['contact_fax']:'Không có',
						'contact_email' => $contact['contact_email'],
						'contact_add' => $contact['contact_add'],
						'contact_content' => $contact['contact_content'],
						'contact_time' => formatTime($contact['contact_time'], 2),
					));
				$this_menu .= ' | Thông tin liên hệ';
			break;
			
			case '6':
				$contact = @mysql_fetch_array(@mysql_query("SELECT * FROM w3style_contacts WHERE id = ".$_GET['id']));
                    $tpl->assign(
                        array(
                            'contact_title' => $contact['contact_title'],
                            'contact_name' => $contact['contact_name'],
                            'contact_email' => $contact['contact_email'],
                        ));
				$this_menu .= ' | Trả lời';
			break;
			}
		break;
		
		case '8':
			$this_menu = '| Cấu hình chung';
			switch($sub_menu) {
			case '0':
				$tpl->assign(
					array(
						'option_name' => get_option('name'),
						'option_email' => get_option('email'),
						'option_desc' => get_option('description'),
						'option_key' => get_option('keywords'),
						'option_paging' => get_option('paging'),
					));
				$this_menu .= ' | Thêm sản phẩm';
			break;
					
			case '1':
				$tpl->assign(
					array(
						'report_check1' => (get_option('report') == 1)?'checked=""':'',
						'report_check0' => (get_option('report') == 0)?'checked=""':'',
						'report_info' => get_option('report_info'),
					));
				$this_menu .= ' | Thông báo';
			break;
				
			case '2':
				$tpl->assign(
					array(
						'close_check1' => (get_option('close') == 1)?'checked=""':'',
						'close_check0' => (get_option('close') == 0)?'checked=""':'',
						'close_info' => get_option('close_info'),
					));
				$this_menu .= ' | Đóng cửa';
			break;
			}
		break;
		////////////////////////////////////////////////////
		// case '5':
			// $this_menu = '| Sản phẩm';
			// switch($sub_menu) {
			// case '0':
				
				// $this_menu .= ' | Thêm sản phẩm';
			// break;
					
			// case '1':				
				// $this_menu .= ' | Danh sách';
				// break;
			// }
		// break;
		//////////////////////////////////////////////////
    }	
	
	if(check_level() >= 2 && !in_array($menu, array('1', '5', '6', '7', '8'))) {
        $tpl->parse('cp_'.$menu.'_'.$sub_menu);
    }
    elseif(check_level() >= 3 && !in_array($menu, array('1', '6', '7', '8'))) {
        $tpl->parse('cp_'.$menu.'_'.$sub_menu);
    }
    elseif(check_level() >= 4 && !in_array($menu, array('6', '9'))) {
        $tpl->parse('cp_'.$menu.'_'.$sub_menu);
    }
    elseif(check_level() >= 9) {
        $tpl->parse('cp_'.$menu.'_'.$sub_menu);
    }
	elseif(check_level() == 1 OR check_level() == 0) {
		Redirect("Không có quyền truy cập", "w3style-logout.php");
	}
	
    $menu_level = '';
	if(check_level() >= 4) $menu_level .= @file_get_contents('templates/level_4.html');
    if(check_level() >= 2) $menu_level .= @file_get_contents('templates/level_2.html');
    if(check_level() >= 3) $menu_level .= @file_get_contents('templates/level_3.html');    
    if(check_level() >= 9) $menu_level .= @file_get_contents('templates/level_9.html');
	
	$if_user = @mysql_fetch_array(@mysql_query("SELECT * FROM w3style_users WHERE id = ".$_SESSION['user']['id']));
	$q_list_unread = @mysql_query("SELECT * FROM w3style_messages WHERE message_read = '0' AND message_to = ".$_SESSION['user']['id']." ORDER BY id DESC");
	while($list_unread = @mysql_fetch_array($q_list_unread)) {
		$msg_from = @mysql_fetch_array(@mysql_query("SELECT * FROM w3style_users WHERE id = ".$_SESSION['user']['id']));
		$tpl->assign(
			array(
				'msg_from_name' => $msg_from['user_fullname'],
				'msg_from_avatar' => ($msg_from['user_avatar'] == null)?"../s-panel/templates/assets/img/find_user.png":$msg_from['user_avatar'],
				'message_content' => catchuoi(strip_tags($list_unread['message_content']), 10),
			));
		$tpl->parse('list_unread');
	}
	$last_visit = @mysql_fetch_array(@mysql_query("SELECT user_lastvisit FROM w3style_users WHERE id = ".$_SESSION['user']['id']));
    $tpl->assign(
        array(
			'menu_level' => $menu_level,
            'version' => $version['name'].' '.$version['value'],
            'this_menu' => $this_menu,
			'name_user' => $if_user['user_fullname'],
			'avatar_user' =>($if_user['user_avatar'] == null)?"../s-panel/templates/assets/img/find_user.png":$if_user['user_avatar'],
            'messages_new' => @mysql_num_rows(@mysql_query("SELECT id FROM w3style_messages WHERE message_read = '0' AND message_to = ".$_SESSION['user']['id'])),
            'total_user' => @mysql_num_rows(@mysql_query("SELECT id FROM w3style_users")),
			'last_visit' => formatTime($last_visit['user_lastvisit'], 4),
            'menu' => $menu,
            'sub_menu' => $sub_menu,
        ));
    $tpl->tpl_out();
	$sql = @mysql_query("UPDATE w3style_users SET user_lastvisit = ". time() ." WHERE  id = ".$_SESSION['user']['id']);
}

else header('Location: w3style-login.php');

?>