<?php
define('W3STYLE',true);
include('../#includes/config.php');
if(check_log() == true & check_level() >= 4) {
	if($_POST['show']) {
		@mysql_query("UPDATE w3style_modules SET mod_home = 0 WHERE mod_home = 1");
		foreach($_POST['show'] as $id) @mysql_query("UPDATE w3style_modules SET mod_home = 1 WHERE id = ".$id);
		header('Location: index.php?m=1&sm=1');
	}
	if($_POST['cat_type']) {
		$check_count = @mysql_num_rows(@mysql_query("SELECT * FROM w3style_modules WHERE mod_name = '".$_POST['cat_type']."'"));
		if($check_count == 1) {
			Redirect("Kiểu danh mục này đã có, hãy đặt 1 kiểu danh mục khác", "index.php?m=1&sm=1");			
		}
		@mysql_query("INSERT INTO w3style_modules(mod_name, mod_home, mod_type) VALUES('".$_POST['cat_type']."', 0, 'menu')");		
		Redirect("Cập nhật thành công kiểu danh mục", "index.php?m=1&sm=1");		
	}
}

else echo "Hacking attempt";

?>