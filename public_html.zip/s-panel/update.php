<?php
define('W3STYLE',true);
include('../#includes/config.php');

if(check_log() == true && check_level() >= 4) {
	if($_POST['type'] == "color") {
		$color_update = $_POST['color'];

		if($color_update == "red" ||$color_update == "green" ||$color_update == "null" ) {
	        @mysql_query("UPDATE w3style_options SET option_value = '". $color_update ."' WHERE option_key = 'color'");
	        echo "1";
		} else {
			echo "0";
		}
	} else if($_POST['type'] == "account") {
		$username = $_POST['username'];
		$password = $_POST['password'];

		if(@mysql_query("UPDATE w3style_options SET option_value = '". $username ."' WHERE option_key = 'username'") && @mysql_query("UPDATE w3style_options SET option_value = '". $password ."' WHERE option_key = 'password'")) {
			@mysql_query("UPDATE w3style_options SET option_value = '1' WHERE option_key = 'kick'");
			echo "1";
		} else {
			echo "0";
		}
	}
}
?>