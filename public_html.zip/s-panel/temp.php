<?php
define('W3STYLE',true);
include('../#includes/config.php');
if(check_log() == true) {
    if($_GET['type'] == 'edit'){
        @mysql_query("UPDATE w3style_templates SET tpl_active = '0'");
        @mysql_query("UPDATE w3style_templates SET tpl_active = '1' WHERE id = ".$_POST['change_temp']);
        header('Location: index.php');
    }
    else header('Location: index.php');
}

else echo "Hacking attempt";


?>