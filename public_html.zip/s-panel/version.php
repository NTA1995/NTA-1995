<?php
$version = array(
    'name'  => '',
    'value' => '1.0.0',
    'time'  => '1402230000',
);

?>