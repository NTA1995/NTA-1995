<?php

if(!$_POST['id']) { Redirect("Access Denied!!!", URL_SITE); return;} else {
	$id = ($_POST['id']);
	$h_coin = ($_POST['h_coin']);
	
	@mysql_fetch_array(@mysql_query("UPDATE w3style_contacts SET contact_numcoin = ". $h_coin ." WHERE id = ".$id));
}

?>