<?php
define('W3STYLE',true);
$cookie_name = "website";
$cookie_value = $_COOKIE[$cookie_name];

if(!isset($_COOKIE[$cookie_name])) {
	Redirect("Chưa đăng nhập", URL_SITE);
} else {
	$w3style->assign(
            array(      
                'url' => $cookie_value,   
            )); 
}

?>