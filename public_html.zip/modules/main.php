<?php
define('W3STYLE',true);
if(!isset($_COOKIE["website"])) {
} else {
    Redirect("", "/home");
}