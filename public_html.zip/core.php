<?php
define('W3STYLE',true);
include('#includes/config.php');	
echo '{"result":"'.get_option('color').'","kick":'.get_option('kick').'}';
?>