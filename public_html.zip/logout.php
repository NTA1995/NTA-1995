<?php
function Redirect($Msg,$Link)
        {
            echo "<script language=\"javascript\">";
            if($Msg!="") echo "alert('$Msg');";
            if($Link!="") echo "window.location.href='$Link';";
            echo "</script>";
            break;
        }
setcookie("website", "", time() - 3600);
Redirect("", "/");
?>