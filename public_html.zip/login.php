<?php

if($_POST['url_web'] == "" || $_POST['username'] == "" || $_POST['password'] == "") {
    Redirect("Bạn chưa nhập đầy đủ thông tin", "/");

} else {
    $username = addslashes($_POST['username']);
    $password = addslashes($_POST['password']);

    define('W3STYLE',true);
    include('#includes/config.php');    

    $check_username = @mysql_num_rows(@mysql_query("SELECT * FROM w3style_options WHERE option_key = 'username' and option_value = '".$username."'"));
    $check_password = @mysql_num_rows(@mysql_query("SELECT * FROM w3style_options WHERE option_key = 'password' and option_value = '".$password."'"));
    
    if($check_username == 1 && $check_password == 1) {
         $cookie_name = "website";
        $cookie_value = "";
        $cookie_value = ($_POST['url_web']);
        setcookie($cookie_name, $cookie_value, time() + (86400 * 1), "/"); // 86400 = 1 day
        Redirect("", "/home");
    } else {
        Redirect("Tài khoản hoặc mật khẩu không đúng", "/");
    }

   


    function Redirect($Msg,$Link)
            {
                echo "<script language=\"javascript\">";
                if($Msg!="") echo "alert('$Msg');";
                if($Link!="") echo "window.location.href='$Link';";
                echo "</script>";
                break;
            }
    //Redirect("", "/home");
}
?>