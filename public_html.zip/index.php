<?php
define('W3STYLE',true);
include('#includes/config.php');	
$w3style = new W3STYLE(false);
if ($w3style->not_found == true) {
    $w3style->tpl_start('404.html');
    $w3style->assign(
        array(
            'web_url' => URL_SITE,
            'web_tpl' => TPL,
        ));
    $w3style->tpl_out();
}
elseif ($w3style->cache_check == false) {
    if (get_option('close') == 1) {
        $w3style->tpl_start('close.html');
        $w3style->assign(
            array(
                'web_url' => URL_SITE,
                'web_tpl' => TPL,
                'web_title' => get_option('name'),
                'web_description' => get_option('description'),
                'web_keywords' => get_option('keywords'),
                'close_info' => get_option('close_info'),
            ));
        $w3style->tpl_out();
    }
    else {
        $w3style->tpl_start('default.html');
		
        switch($w3style->rewrite_menu){ 
            case 'main':
                $this_title = get_option('name');
				include 'modules/main.php';
                $w3style->parse('main');
            break;
			
			
			case 'home':				
				include 'modules/home.php';
                $w3style->parse('home');                
                $this_title = get_option("name");
			break;
        }		
					
        if(get_option('report') == 1 && !$_COOKIE['report']) $w3style->parse('report');
        online();
        $user_on = @mysql_num_rows(@mysql_query("SELECT id FROM w3style_onlines WHERE online_user > 0"));
        $guest_on = @mysql_num_rows(@mysql_query("SELECT id FROM w3style_onlines WHERE online_user <= 0"));
        list($total_visit) = @mysql_fetch_array(@mysql_query("SELECT MAX(id) FROM w3style_onlines"));
        $w3style->assign(
            array(
                'this_time' => formatTime(time(), 4),
                'this_url' => this_url(),
                'web_url' => URL_SITE,
                'web_title' => $this_title,
                'web_description' => get_option('description'),
				'spcounts' => ($_SESSION['spcount'] == NULL)?'0':$_SESSION['spcount'],
                'web_keywords' => get_option('keywords'),
                'web_tpl' => TPL,
                'total_product' => @mysql_num_rows(@mysql_query("SELECT id FROM w3style_products")),
                'total_visit' => $total_visit,
                'user_online' => $user_on,
                'guest_online' => $guest_on,
            ));
        $w3style->tpl_out();
    }
    
}

?>