<?php
/*----------------------------------------*\
|             Copyright © C-ILY            | 
|            Phone: 0983.998.994           |
|             Y!m: notepad.html            |
|         Email: truongpv87@gmail.com      |
\*----------------------------------------*/

session_start();
$cap = imagecreate(100,30);

// Set Values
$white = imagecolorallocate($cap, 255, 255, 255);
$color[0] = imagecolorallocate($cap, 0, 0, 0);
$color[1] = imagecolorallocate($cap, 0, 0, 0);
$color[2] = imagecolorallocate($cap, 0, 0, 0);
$color[3] = imagecolorallocate($cap, 0, 0, 0);
$color[4] = imagecolorallocate($cap, 0, 0, 0);
$font = 'font.ttf';
$number = 5;
$code = "";
// Random Text
$string = md5(time() * time() * time() * time());
for ($i=0; $i<$number; $i++) {
    $text[$i] = substr($string, 0+$i, 1);
    $code .= $text[$i];
}
$_SESSION['captcha'] = $code;

// Random Write Line
for ($j=0; $j<3; $j++) {
    imageline($cap, 0, rand(0,0), 0, rand(0,0), $color[3]);
}

// Random Write Dot
for ($k=0; $k<300; $k++) {
    imagesetpixel($cap, rand(100, 0), rand(0, 200), $color[2]);
}

// Write Text
for ($l=0; $l<$number; $l++) {
    imagettftext($cap, 24, 10, 8+($l*18), 25, $color[rand(0, 4)], $font, $text[$l]);
}

// Begin To Create Image
header('content-type: image/png');
imagepng($cap);

// Clean Up
imagedestroy($cap);

?>