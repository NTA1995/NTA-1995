<?php

/*----------------------------------------*\
|             Copyright © C-ILY            | 
|            Phone: 0983.998.994           |
|             Y!m: notepad.html            |
|         Email: truongpv87@gmail.com      |
\*----------------------------------------*/
header("Location: security.html");

?>