var date = new Date();
date.setTime(date.getTime() + (60000*60));
$(function(){
    if($.cookie('lang')=='EN'){
        langEN();
    }

    if($.cookie('lang')=='VI'){
        langVN();
    }
})

function langVN(){
    $.cookie('lang', null, { path: '/', expires: date });
    location.reload();
}

function langEN(){
    $(document).translate('english');
    $.cookie('lang', 'EN', { path: '/', expires: date });
}