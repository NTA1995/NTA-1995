<?php
define('hl',true);
include('../../../#includes/config.php');
if(check_log() == true & check_level() >= 2) {
    if($_POST['title'] == '' or $_POST['title'] == ' ') $_POST['title'] = 'No name';
    if(!$_POST['thumb']){
        @mysql_query("UPDATE hl_datas SET data_name = '".$_POST['title']."', data_info = '".$_POST['desc']."' WHERE data_url = '".$_POST['url']."'");
    }
    else {
        @mysql_query("UPDATE hl_datas SET data_name = '".$_POST['title']."', data_info = '".$_POST['desc']."' WHERE data_thumb = '".$_POST['thumb']."'");
    }
}

else echo "Hacking attempt";
?>