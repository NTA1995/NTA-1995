<?php
header("Location: security.html");
?>