<?php
define('hl',true);
include('../../../#includes/config.php');

if(check_log() == true & check_level() >= 2) {
    if($_GET['type']=='image') $uploaddir = '../../uploads/images/';
    elseif($_GET['type']=='media') $uploaddir = '../../uploads/medias/';
    elseif($_GET['type']=='other') $uploaddir = '../../uploads/other/';
    $uploadname =  basename($_FILES['userfile']['name']);
    $uploadname = convert($uploadname);
    $newName = date('U', time()) . '_' . $uploadname;
    $uploadfile = $uploaddir .  $newName;
    if(file_exists($uploadfile)) echo "success";
    elseif (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
        echo $newName;
        if($_GET['type']=='image') {
            if(type($uploadname) != 'gif') createThumbs($uploadfile,$uploaddir.'thumbs-'.$newName,$widththumbs);
            else copy($uploadfile,$uploaddir.'thumbs-'.$newName);
            @mysql_query("INSERT INTO hl_datas (data_name, data_url, data_thumb, data_time, data_type) VALUES ('Image', '".get_option('url').'/data/uploads/images/'.$newName."', '".get_option('url').'/data/uploads/images/'.'thumbs-'.$newName."', ".time().",1)");      
        }
        elseif($_GET['type']=='media') @mysql_query("INSERT INTO hl_datas (data_name, data_url, data_time, data_type) VALUES ('Media', '".get_option('url').'/data/uploads/medias/'.$newName."', ".time().",2)"); 
        else @mysql_query("INSERT INTO hl_datas (data_name, data_url, data_time, data_type) VALUES ('Other', '".get_option('url').'/data/uploads/other/'.$newName."', ".time().",3)"); 
    } 
    else {
        echo "error";
    }
}

else echo "Hacking attempt";

function convert($str) {
	
	$str = html_entity_decode($str);
 	$str = mb_convert_case($str,MB_CASE_TITLE,'utf-8');
 	$str = trim(strtolower($str));
	$str = preg_replace("/(à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ)/", 'a', $str);
	$str = preg_replace("/(è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ)/", 'e', $str);
	$str = preg_replace("/(ì|í|ị|ỉ|ĩ)/", 'i', $str);
	$str = preg_replace("/(ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ)/", 'o', $str);
	$str = preg_replace("/(ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ)/", 'u', $str);
	$str = preg_replace("/(ỳ|ý|ỵ|ỷ|ỹ)/", 'y', $str);
	$str = preg_replace("/(đ|Đ)/", 'd', $str);
	$str = preg_replace('/[^A-Za-z0-9\-\.]/', '-', $str);
//	$str = preg_replace('/\W+/', '-', $str);
	//$str = str_replace(' ', '-', $str);
	return $str;
 }