<?php 
define('W3STYLE',true);
include('../../../../#includes/config.php');
@include('../languages/vi.php');

if(check_log() == true & check_level() >= 2) {
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <link rel="stylesheet" type="text/css" href="style.css" />
    <script type="text/javascript" src="../../jquery-1.4.2.min.js" ></script>
    <script type="text/javascript" src="../../avim.js" ></script>
    <script language="JavaScript" type="text/javascript">
    
    /* ---------------------------------------------------------------------- *\
      Function    : insertImage()
      Description : Inserts image into the WYSIWYG.
    \* ---------------------------------------------------------------------- */
    function insertImage() {
        <?php if($_GET['type']=='up') { ?>
        $.ajax({
    		type: 'POST', url: '../update.php', data: 'thumb=' + $('#url').val() + '&title=' + $('#title').val() + '&desc=' + $('#description').val(),
            complete: function(){
    			<?php if(isset($_GET['action']) && $_GET['action'] == 'attach'): ?>
    				var html = '' +
    					'<tr data-url="' + $('#url').val().replace('thumbs-', '') + '">' +
    						'<td>' +
    							'<a class="remove">&nbsp;</a>' +
    						'</td>' +
							'<td>' +
								'<img style="width: 300px; max-height: 350px;" src="' + $('#url').val() +'">' +
							'</td>' +
						'</tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr>'
					;
					parent.$('.product-images table').append(html);
					var value = parent.$('input[name=attach_image]').val();					
					parent.$('input[name=attach_image]').val(value + $('#url').val().replace('thumbs-', '') + ',');					
    			<?php else: ?>
					parent.$('#imgdemos > img').attr('src',$('#url').val());
					parent.$('#imgdemos > input').val($('#url').val());    			
    			<?php endif; ?>

				parent.$.akModalRemove();
			}
        });
      <?php } else { ?>
    			<?php if(isset($_GET['action']) && $_GET['action'] == 'attach'): ?>
    				var html = '' +
    					'<tr data-url="' + $('#url').val().replace('thumbs-', '') + '">' +
    						'<td>' +
    							'<a class="remove">&nbsp;</a>' +
    						'</td>' +
							'<td>' +
								'<img style="width: 300px; max-height: 350px;" src="' + $('#url').val() +'">' +
							'</td>' +
						'</tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr>'
					;
					parent.$('.product-images table').append(html);
					var value = parent.$('input[name=attach_image]').val();					
					parent.$('input[name=attach_image]').val(value + $('#url').val().replace('thumbs-', '') + ',');
    			<?php else: ?>
					parent.$('#imgdemos > img').attr('src',$('#url').val());
					parent.$('#imgdemos > input').val($('#url').val());    			
    			<?php endif; ?>
      	parent.$.akModalRemove();
      <?php } ?>
      
      
    }
    
    </script>
</head>

<body>
<ul id="linkbar">
    <li></li>
    <li<?php if($_GET['type']=='up') echo ' class="curent"'; ?>><a href="insert_imgdemo.php?type=up&action=<?php echo $_GET['action'] ?>" target="_self"><?php echo $language['editer_insert_up']; ?></a></li>
    <li<?php if($_GET['type']=='url') echo ' class="curent"'; ?>><a href="insert_imgdemo.php?type=url&action=<?php echo $_GET['action'] ?>" target="_self"><?php echo $language['editer_insert_url']; ?></a></li>
    <li<?php if($_GET['type']=='lib') echo ' class="curent"'; ?>><a href="insert_imgdemo.php?type=lib&action=<?php echo $_GET['action'] ?>" target="_self"><?php echo $language['editer_insert_lib']; ?></a></li>
<br clear="all"/>
</ul>
<div id="container">
    <div id="content">
    <?php if($_GET['type']=='up'){ ?>
    <script type="text/javascript" src="../ajaxupload.js" ></script>
    <script type="text/javascript">
    $(document).ready(function(){
		var button = $('#upload'), interval;
		new AjaxUpload(button, {
			action: '../upload.php?type=image', 
			onSubmit : function(file, ext){
			 
				if (ext && /^(jpg|png|jpeg|JPG|GIF|PNG|JPEG|gif)$/.test(ext)){		
    				button.text('<?php echo $language['editer_uploading']; ?>');
    								
    				this.disable();
    				
    				interval = window.setInterval(function(){
    					var text = button.text();
    					if (text.length < '<?php echo $language['editer_uploading']; ?>'.length+5){
    						button.text(text + '.');					
    					} else {
    						button.text('<?php echo $language['editer_uploading']; ?>');				
    					}
    				}, 200);
				} else {					
					alert('<?php echo $language['editer_not_type']; ?>');
					return false;				
				}
			},
			onComplete: function(file, response){
				button.text('<?php echo $language['editer_finish']; ?>');			
				window.clearInterval(interval);
				$('.info').show();
				$('.file').html('<img src="<?php echo get_option('url'); ?>/data/uploads/images/'+response+'" /><input id="url" type="hidden" value="<?php echo get_option('url'); ?>/data/uploads/images/'+response+'" />');						
			}
		});
        
	});
    </script>
    <h1><?php echo $language['editer_image_up_t']; ?></h1>
    <button id="upload"><?php echo $language['editer_upload']; ?></button>
    <p><?php echo $language['editer_size']; ?>: 2Mb</p>
    <p><?php echo $language['editer_type']; ?>: jpg, png, jpeg, gif</p>
    <p style="color: red;">(*) <?php echo $language['editer_warning']; ?></p>
    <ol>
        <li class="file"></li>
        <li class="info">
            <table>
            <tr>
            	<td valign="top"><?php echo $language['editer_name']; ?>:</td>
            	<td><input type="text" id="title" style="width: 180px;" value="" /></td>
            </tr>
            <tr>
            	<td valign="top"><?php echo $language['editer_description']; ?>:</td>
            	<td><textarea id="description" style="width: 180px;"></textarea></td>
            </tr>
            </table>
        </li>
    </ol>
    
    
    <?php } elseif($_GET['type']=='url'){ ?>
    <h1><?php echo $language['editer_image_url_t']; ?></h1>
    <ul class="url">
        <li>
            <table>
            <tr>
            	<td valign="top" width="100px"><?php echo $language['editer_image_url']; ?>:</td>
            	<td><input type="text" id="url" style="width: 200px;" value="http://" /></td>
            </tr>
            <tr>
            	<td valign="top"><?php echo $language['editer_name']; ?>:</td>
            	<td><input type="text" id="title" style="width: 200px;" value=" " /></td>
            </tr>
            <tr>
            	<td valign="top"><?php echo $language['editer_description']; ?>:</td>
            	<td><textarea id="description" style="width: 200px;"></textarea></td>
            </tr>
            </table>
        </li>
    </ul>
    
    <?php } elseif($_GET['type']=='lib'){ ?>
    <script language="javascript">
        $(document).ready(function(){
            $('#imgdemo > span > img').click(function(){
                $('#imgdemo').hide();  
                $('.info').show();
                $('.file').html('<img src="' + $(this).attr('src') + '" /><input id="url" type="hidden" value="' + $(this).attr('value') + '" />');
                $('#title').val($(this).attr('name')); 
                $('#description').text($(this).attr('desc'))
            });
        });
    </script>
    <h1><?php echo $language['editer_image_lib_t']; ?></h1>
    <div id="imgdemo">
        <?php 
            $current_page = ($_GET['page'])?$_GET['page']:1;
            $start = 15*($current_page-1);
            $datas = @mysql_query("SELECT * FROM w3style_datas WHERE data_type=1 ORDER BY id DESC LIMIT ".$start.",15");
            $total = @mysql_num_rows(@mysql_query("SELECT * FROM w3style_datas WHERE data_type=1"));
            while ($data = mysql_fetch_array ($datas))
            {
        ?>
        <span class="demo"><img title="<?php echo $language['editer_ok']; ?>" src="<?php echo $data['data_url']; ?>" value="<?php echo $data['data_url']; ?>" name="<?php echo $data['data_name']; ?>" desc="<?php echo $data['data_info']; ?>" /></span>
        <?php
            }
         ?>
        <br clear="all" />
        <?php 
            echo paging(15,$current_page,$total,'insert_imgdemo.php?wysiwyg='.$_GET['wysiwyg'].'&type=lib&action=' . $_GET['action'],'&page=',false);
        ?>
    </div>
    <ol>
        <li class="file"></li>
        <li class="info">
            <table>
            <tr>
            	<td valign="top"><?php echo $language['editer_name']; ?>:</td>
            	<td><input type="text" id="title" style="width: 180px;" /></td>
            </tr>
            <tr>
            	<td valign="top"><?php echo $language['editer_description']; ?>:</td>
            	<td><textarea id="description" style="width: 180px;"></textarea></td>
            </tr>
            </table>
        </li>
    </ol>
    <?php } ?>
    </div>
    <div align="right" style="padding-top: 5px;"><input type="submit" value="<?php echo $language['editer_insert']; ?>" onClick="javascript:insertImage();" style="font-size: 12px;" />&nbsp;<input type="submit" value="<?php echo $language['editer_cancel']; ?>" onClick="parent.$.akModalRemove();" style="font-size: 12px;" /></div>
</div>
</body>
</html>
<?php }

else echo "Hacking attempt";
?>