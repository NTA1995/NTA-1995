<?php 
@include('../languages/vi.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
</head>
<script language="JavaScript" type="text/javascript">

function insertHyperLink() {
  var hyperLink = document.getElementById('linkType').value + document.getElementById('url').value;
  parent.document.getElementById('wysiwyg' +  '<?php echo $_GET['wysiwyg'] ?>').contentWindow.document.execCommand("CreateLink", false, hyperLink);
}

</script>
<style>
    * {
        margin: 0;
        padding: 0;
    }
    
    body {
        background-color: #EEE;
    }
    
    button, input[type="submit"] {
        background-color: #FFF;
        height: 22px;
        padding: 0 5px;
        border: #BBBBBB solid 1px;
        -moz-border-radius: 10px;
        -webkit-border-radius: 10px;
        -khtml-border-radius: 10px;
        border-radius: 10px;
    }
    
    button:hover, input[type="submit"]:hover {
        border-color: #464646;
        cursor: pointer;
    }
</style>
<body>

<table border="0" cellpadding="0" cellspacing="0" style="padding: 10px;"><tr><td>

<span style="font-family: arial, verdana, helvetica; font-size: 11px; font-weight: bold;"><?php echo $language['editer_link_title']; ?>:</span>
<table width="280" border="0" cellpadding="0" cellspacing="0" style="background-color: #F7F7F7; border: 2px solid #FFFFFF; padding: 5px;">
 <tr>
  <td style="padding-bottom: 2px; width: 50px; font-family: arial, verdana, helvetica; font-size: 11px;"><?php echo $language['editer_link_type']; ?>:</td>
	<td style="padding-bottom: 2px;">
	<select name="linkType" id="linkType" style="margin-right: 10px; font-size: 10px;">
	 <option value="http://">http:</option>
	 <option value="https://">https:</option>
	 <option value="mailto:">mailto:</option>
	</select>
	</td>	
 </tr>
 <tr>
  <td style="padding-bottom: 2px; padding-top: 0px; font-family: arial, verdana, helvetica; font-size: 11px;"><?php echo $language['editer_link_url']; ?>:</td>
	<td style="padding-bottom: 2px; padding-top: 0px;"><input type="text" name="url" id="url" value=""  style="font-size: 10px; width: 100%;"></td>
 </tr>
</table>	

<div align="right" style="padding-top: 5px;"><input type="submit" value="<?php echo $language['editer_insert']; ?>" onClick="insertHyperLink();parent.$.akModalRemove();" style="font-size: 12px;" >&nbsp;<input type="submit" value="<?php echo $language['editer_cancel']; ?>" onClick="parent.$.akModalRemove();" style="font-size: 12px;" ></div>

</tr></td></table>

</body>
</html>
