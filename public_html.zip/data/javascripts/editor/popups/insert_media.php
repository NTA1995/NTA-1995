<?php 
define('W3STYLE',true);
include('../../../../#includes/config.php');
@include('../languages/vi.php');

if(check_log() == true & check_level() >= 2) {
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <link rel="stylesheet" type="text/css" href="style.css" />
    <script type="text/javascript" src="../../jquery-1.4.2.min.js" ></script>
    <script type="text/javascript" src="../../avim.js" ></script>
    <script language="JavaScript" type="text/javascript">
    
    /* ---------------------------------------------------------------------- *\
      Function    : insertImage()
      Description : Inserts image into the WYSIWYG.
    \* ---------------------------------------------------------------------- */
    function insertMedia() {
        switch($('#type').val()) {
            case '1':
                var media = '<div style="text-align: '+$('#align').val()+'"><img style="width: '+$('#w').val()+'px; height: '+$('#h').val()+'px;" class="MediaF" src="<?php echo get_option('url'); ?>/data/flash/player.swf?file='+$('#url').val()+'" \/></div>';
                break;
            case '2':
                var media = '<div style="text-align: '+$('#align').val()+'"><img style="width: '+$('#w').val()+'px; height: '+$('#h').val()+'px;" class="MediaW" autostart="false" src="'+$('#url').val()+'" \/></div>';
                break;
            case '3':
                var media = '<div style="text-align: '+$('#align').val()+'"><img style="width: '+$('#w').val()+'px; height: '+$('#h').val()+'px;" class="MediaF" src="<?php echo get_option('url'); ?>/data/flash/player.swf?file='+$('#url').val()+'" \/></div>';
                break;
            case '4':
                var media = '<div style="text-align: '+$('#align').val()+'"><img style="width: '+$('#w').val()+'px; height: '+$('#h').val()+'px;" class="MediaF" src="<?php echo get_option('url'); ?>/data/flash/player.swf?file='+$('#url').val()+'" \/></div>';
                break;
            case '5':
                var media = '<div style="text-align: '+$('#align').val()+'"><img style="width: '+$('#w').val()+'px; height: '+$('#h').val()+'px;" class="MediaW" autostart="false" src="'+$('#url').val()+'" \/></div>';
                break;
            case '6':
                var media = '<div style="text-align: '+$('#align').val()+'"><img style="width: '+$('#w').val()+'px; height: '+$('#h').val()+'px;" class="MediaF" src="<?php echo get_option('url'); ?>/data/flash/player.swf?file='+$('#url').val()+'" height="'+$('#h').val()+'" width="'+$('#w').val()+'" \/></div>';
                break;
        }
        <?php if($_GET['type']=='up') { ?>
        $.ajax({
    		type: 'POST', url: '../update.php', data: 'url=' + $('#url').val() + '&title=' + $('#title').val() + '&desc=' + $('#description').val(),
            complete: function(){
                //parent.insertHTML(media, '<?php echo $_GET['wysiwyg'] ?>');
                parent.insertHtml(media);
                parent.$.akModalRemove();
			}
        });
      <?php } else { ?>
        //parent.insertHTML(media, '<?php echo $_GET['wysiwyg'] ?>');
        parent.insertHtml(media);
        parent.$.akModalRemove();
      <?php } ?>
      
    }
    
    </script>
</head>

<body>
<ul id="linkbar">
    <li></li>
    <li<?php if($_GET['type']=='up') echo ' class="curent"'; ?>><a href="insert_media.php?wysiwyg=<?php echo $_GET['wysiwyg']; ?>&type=up" target="_self"><?php echo $language['editer_insert_up']; ?></a></li>
    <li<?php if($_GET['type']=='url') echo ' class="curent"'; ?>><a href="insert_media.php?wysiwyg=<?php echo $_GET['wysiwyg']; ?>&type=url" target="_self"><?php echo $language['editer_insert_url']; ?></a></li>
    <li<?php if($_GET['type']=='lib') echo ' class="curent"'; ?>><a href="insert_media.php?wysiwyg=<?php echo $_GET['wysiwyg']; ?>&type=lib" target="_self"><?php echo $language['editer_insert_lib']; ?></a></li>
<br clear="all"/>
</ul>
<div id="container">
    <div id="content">
    <?php if($_GET['type']=='up'){ ?>
    <script type="text/javascript" src="../ajaxupload.js" ></script>
    <script type="text/javascript">
    $(document).ready(function(){
		var button = $('#upload'), interval;
		new AjaxUpload(button, {
			action: '../upload.php?type=media', 
			onSubmit : function(file, ext){
			 
				if (ext && /^(mp3|wma|mp4|flv|wmv)$/.test(ext)){		
    				button.text('<?php echo $language['editer_uploading']; ?>');
    								
    				this.disable();
    				
    				interval = window.setInterval(function(){
    					var text = button.text();
    					if (text.length < '<?php echo $language['editer_uploading']; ?>'.length+5){
    						button.text(text + '.');					
    					} else {
    						button.text('<?php echo $language['editer_uploading']; ?>');				
    					}
    				}, 200);
				} else {					
					alert('<?php echo $language['editer_not_type']; ?>');
					return false;				
				}
			},
			onComplete: function(file, response){
				button.text('<?php echo $language['editer_finish']; ?>');			
				window.clearInterval(interval);
				$('.info').show();
				$('#url').val('<?php echo get_option('url'); ?>/data/uploads/medias/'+file);
                switch(file.substr(file.length-3,3)){
                    case 'mp3':
                        var type = 1;
                        break;
                    case 'wma':
                        var type = 2;
                        break;
                    case 'mp4':
                        var type = 3;
                        break;
                    case 'flv':
                        var type = 4;
                        break;
                    case 'wmv':
                        var type = 5;
                        break;
                }
				$('#type').val(type);						
			}
		});
        
	});
    </script>
    <h1><?php echo $language['editer_media_up_t']; ?></h1>
    <button id="upload"><?php echo $language['editer_upload']; ?></button>
    <p><?php echo $language['editer_size']; ?>: 40Mb</p>
    <p><?php echo $language['editer_type']; ?>: mp3, wma, mp4, flv, wmv</p>
    <p style="color: red;">(*) <?php echo $language['editer_warning']; ?></p>
    <ul class="url">
        <li class="info">
            <table>
            <input id="url" type="hidden" />
            <tr>
            	<td valign="top" width="100px"><?php echo $language['editer_media_type']; ?>:</td>
            	<td>
                    <select id="type" disabled="disabled">
                        <option value="1">MP3</option>
                        <option value="2">WMA</option>
                        <option value="3">MP4</option>
                        <option value="4">FLV</option>
                        <option value="5">WMV</option>
                    </select>
                </td>
            </tr>
            <tr>
            	<td valign="top"><?php echo $language['editer_name']; ?>:</td>
            	<td><input type="text" id="title" style="width: 200px;" value="" /></td>
            </tr>
            <tr>
            	<td valign="top"><?php echo $language['editer_description']; ?>:</td>
            	<td><textarea id="description" style="width: 200px;"></textarea></td>
            </tr>
            <tr>
            	<td valign="top"><?php echo $language['editer_align']; ?>:</td>
            	<td>
                    <select id="align">
                        <option value=""><?php echo $language['editer_table_none']; ?></option>
                        <option value="Left"><?php echo $language['editer_table_left']; ?></option>
                        <option value="Right"><?php echo $language['editer_table_right']; ?></option>
                        <option value="Center"><?php echo $language['editer_table_center']; ?></option>
                        <option value="justify"><?php echo $language['editer_table_justify']; ?></option>
                    </select>
                </td>
            </tr>
            <tr>
            	<td valign="top"><?php echo $language['editer_wh']; ?>:</td>
            	<td><input id="w" type="text" style="width: 50px;" value="320" />px <b>X</b> <input id="h" type="text" style="width: 50px;" value="" />px</td>
            </tr>
            </table>
        </li>
    </ul>
    
    
    <?php } elseif($_GET['type']=='url'){ ?>
    <h1><?php echo $language['editer_media_url_t']; ?></h1>
    <ul class="url">
        <li>
            <table>
            <tr>
            	<td valign="top" width="100px"><?php echo $language['editer_media_url']; ?>:</td>
            	<td><input type="text" id="url" style="width: 200px;" value="http://" /></td>
            </tr>
            <tr>
            	<td valign="top"><?php echo $language['editer_media_type']; ?>:</td>
            	<td>
                    <select id="type">
                        <option value="1">MP3</option>
                        <option value="2">WMA</option>
                        <option value="3">MP4</option>
                        <option value="4">FLV</option>
                        <option value="5">WMV</option>
                        <option value="6">SITE URL</option>
                    </select>
                </td>
            </tr>
            <tr>
            	<td valign="top"><?php echo $language['editer_name']; ?>:</td>
            	<td><input type="text" id="title" style="width: 200px;" value=" " /></td>
            </tr>
            <tr>
            	<td valign="top"><?php echo $language['editer_description']; ?>:</td>
            	<td><textarea id="description" style="width: 200px;"></textarea></td>
            </tr>
            <tr>
            	<td valign="top"><?php echo $language['editer_align']; ?>:</td>
            	<td>
                    <select id="align">
                        <option value=""><?php echo $language['editer_table_none']; ?></option>
                        <option value="Left"><?php echo $language['editer_table_left']; ?></option>
                        <option value="Right"><?php echo $language['editer_table_right']; ?></option>
                        <option value="Center"><?php echo $language['editer_table_center']; ?></option>
                        <option value="justify"><?php echo $language['editer_table_justify']; ?></option>
                    </select>
                </td>
            </tr>
            <tr>
            	<td valign="top"><?php echo $language['editer_wh']; ?>:</td>
            	<td><input id="w" type="text" style="width: 50px;" value="320" />px <b>X</b> <input id="h" type="text" style="width: 50px;" value="" />px</td>
            </tr>
            </table>
            <p style="color: red;">(**) <?php echo $language['editer_warning_type']; ?></p>
        </li>
    </ul>
    
    <?php } elseif($_GET['type']=='lib'){ ?>
    <script language="javascript">
        $(document).ready(function(){
            $('.ok').click(function(){
                $('#mediademo').hide();  
                $('.info').show();
                $('#url').val($(this).attr('value')); 
                $('#title').val($(this).attr('name')); 
                $('#description').text($(this).attr('desc'));
                $('#type').val($(this).attr('type'));
            });
        });
    </script>
    <h1><?php echo $language['editer_media_lib_t']; ?></h1>
    <div id="mediademo">
        <table>
            <?php 
                $current_page = ($_GET['page'])?$_GET['page']:1;
                $start = 5*($current_page-1);
                $datas = @mysql_query("SELECT * FROM w3style_datas WHERE data_type=2 ORDER BY id DESC LIMIT ".$start.",5");
                $total = @mysql_num_rows(@mysql_query("SELECT * FROM w3style_datas WHERE data_type=2"));
                while ($data = mysql_fetch_array ($datas))
                {
                    switch(type($data['data_url'])) {
                        case 'mp3': 
                            $thumb = '../icons/mp3.png';
                            $type = 1;
                            break;
                        case 'wma': 
                            $thumb = '../icons/wma.png';
                            $type = 2;
                            break;
                        case 'mp4': 
                            $thumb = '../icons/mp4.png';
                            $type = 3;
                            break;
                        case 'flv': 
                            $thumb = '../icons/flv.png';
                            $type = 4;
                            break;
                        case 'wmv': 
                            $thumb = '../icons/wmv.png';
                            $type = 5;
                            break;
                    }
            ?>
            <tr>
                <td><img src="<?php echo $thumb; ?>" /></td>
                <td style="max-width: 280px; width: 280px;">
                    <p><?php echo $data['data_name']; ?></p>
                    <p><?php echo formatTime($data['data_time'],1); ?></p>
                </td>
                <td><button class="ok" value="<?php echo $data['data_url']; ?>" name="<?php echo $data['data_name']; ?>" desc="<?php echo $data['data_info']; ?>" type="<?php echo $type; ?>"><?php echo $language['editer_ok']; ?></button></td>
            </tr>
            <?php
                }
             ?>
        </table>
    
        <?php 
            echo paging(5,$current_page,$total,'insert_media.php?wysiwyg='.$_GET['wysiwyg'].'&type=lib','&page=',false);
        ?>
    </div>
    <ul class="url">
        <li class="info">
            <table>
            <input id="url" type="hidden" />
            <tr>
            	<td valign="top" width="100px"><?php echo $language['editer_media_type']; ?>:</td>
            	<td>
                    <select id="type" disabled="disabled">
                        <option value="1">MP3</option>
                        <option value="2">WMA</option>
                        <option value="3">MP4</option>
                        <option value="4">FLV</option>
                        <option value="5">WMV</option>
                    </select>
                </td>
            </tr>
            <tr>
            	<td valign="top"><?php echo $language['editer_name']; ?>:</td>
            	<td><input type="text" id="title" style="width: 200px;" value=" " /></td>
            </tr>
            <tr>
            	<td valign="top"><?php echo $language['editer_description']; ?>:</td>
            	<td><textarea id="description" style="width: 200px;"></textarea></td>
            </tr>
            <tr>
            	<td valign="top"><?php echo $language['editer_align']; ?>:</td>
            	<td>
                    <select id="align">
                        <option value=""><?php echo $language['editer_table_none']; ?></option>
                        <option value="Left"><?php echo $language['editer_table_left']; ?></option>
                        <option value="Right"><?php echo $language['editer_table_right']; ?></option>
                        <option value="Center"><?php echo $language['editer_table_center']; ?></option>
                        <option value="justify"><?php echo $language['editer_table_justify']; ?></option>
                    </select>
                </td>
            </tr>
            <tr>
            	<td valign="top"><?php echo $language['editer_wh']; ?>:</td>
            	<td><input id="w" type="text" style="width: 50px;" value="320" />px <b>X</b> <input id="h" type="text" style="width: 50px;" value="" />px</td>
            </tr>
            </table>
        </li>
    </ul>
    <?php } ?>
    </div>
    <div align="right" style="padding-top: 5px;"><input type="submit" value="<?php echo $language['editer_insert']; ?>" onClick="insertMedia();" style="font-size: 12px;" />&nbsp;<input type="submit" value="<?php echo $language['editer_cancel']; ?>" onClick="parent.$.akModalRemove();" style="font-size: 12px;" /></div>
</div>
</body>
</html>
<?php }

else echo "Hacking attempt";
?>