<?php 
define('W3STYLE',true);
include('../../../../#includes/config.php');
@include('../languages/vi.php');

if(check_log() == true & check_level() >= 2) {
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <link rel="stylesheet" type="text/css" href="style.css" />
    <script type="text/javascript" src="../../jquery-1.4.2.min.js" ></script>
    <script type="text/javascript" src="../../avim.js" ></script>
    <script language="JavaScript" type="text/javascript">
    
    /* ---------------------------------------------------------------------- *\
      Function    : insertImage()
      Description : Inserts image into the WYSIWYG.
    \* ---------------------------------------------------------------------- */
    function insertFile() {
        var id = 'file'+Math.floor(Math.random()*11)+Math.floor(Math.random()*11)+Math.floor(Math.random()*11);
        
        <?php if($_GET['type']=='up') { ?>
        $.ajax({
    		type: 'POST', url: '../update.php', data: 'url=' + $('#url').val() + '&title=' + $('#title').val() + '&desc=' + $('#description').val(),
            complete: function(){
                parent.$('#file').after('<p id="'+id+'">-> '+$('#title').val()+'<a style="color: red; cursor: pointer;" onclick="$(\'#'+id+'\').remove();$(\'#filecontent > input\').val($(\'#filecontent > input\').val().replace(\','+$('#title').val()+'|'+$('#url').val()+'\',\'\'));">X</a></p>');
                parent.$('#filecontent > input').val(parent.$('#filecontent > input').val() + ',' + $('#title').val()+'|'+$('#url').val());
                parent.$.akModalRemove();
			}
        });
      <?php } else { ?>
        parent.$('#file').after('<p id="'+id+'">-> '+$('#title').val()+'<a style="color: red; cursor: pointer;" onclick="$(\'#'+id+'\').remove();$(\'#filecontent > input\').val($(\'#filecontent > input\').val().replace(\','+$('#title').val()+'|'+$('#url').val()+'\',\'\'));">X</a></p>');
        parent.$('#filecontent > input').val(parent.$('#filecontent > input').val() + ',' + $('#title').val()+'|'+$('#url').val());
        parent.$.akModalRemove();
      <?php } ?>
    }
    
    </script>
</head>

<body>
<ul id="linkbar">
    <li></li>
    <li<?php if($_GET['type']=='up') echo ' class="curent"'; ?>><a href="insert_file.php?type=up" target="_self"><?php echo $language['editer_insert_up']; ?></a></li>
    <li<?php if($_GET['type']=='url') echo ' class="curent"'; ?>><a href="insert_file.php?type=url" target="_self"><?php echo $language['editer_insert_url']; ?></a></li>
    <li<?php if($_GET['type']=='lib') echo ' class="curent"'; ?>><a href="insert_file.php?type=lib" target="_self"><?php echo $language['editer_insert_lib']; ?></a></li>
<br clear="all"/>
</ul>
<div id="container">
    <div id="content">
    <?php if($_GET['type']=='up'){ ?>
    <script type="text/javascript" src="../ajaxupload.js" ></script>
    <script type="text/javascript">
    $(document).ready(function(){
		var button = $('#upload'), interval;
		new AjaxUpload(button, {
			action: '../upload.php?type=other', 
			onSubmit : function(url, ext){
			 
				if (ext && /^(zip|rar|doc|pdf|xls|xlsx|docx|ppt|mdb|txt|rtf)$/.test(ext)){		
    				button.text('<?php echo $language['editer_uploading']; ?>');
    								
    				this.disable();
    				
    				interval = window.setInterval(function(){
    					var text = button.text();
    					if (text.length < '<?php echo $language['editer_uploading']; ?>'.length+5){
    						button.text(text + '.');					
    					} else {
    						button.text('<?php echo $language['editer_uploading']; ?>');				
    					}
    				}, 200);
				} else {					
					alert('<?php echo $language['editer_not_type']; ?>');
					return false;				
				}
			},
			onComplete: function(url, response){
				button.text('<?php echo $language['editer_finish']; ?>');			
				window.clearInterval(interval);
				$('.info').show();
				$('#url').val('<?php echo get_option('url'); ?>/data/uploads/other/'+response);						
			}
		});
        
	});
    </script>
    <h1><?php echo $language['editer_file_up_t']; ?></h1>
    <button id="upload"><?php echo $language['editer_upload']; ?></button>
    <p><?php echo $language['editer_size']; ?>: 40Mb</p>
    <p><?php echo $language['editer_type']; ?>: zip, rar, txt, rtf, doc, pdf, xls, ppt, mdb, xlsx, docx</p>
    <p style="color: red;">(*) <?php echo $language['editer_warning']; ?></p>
    <ul class="url">
        <li class="info">
            <table>
            <input id="url" type="hidden" />
            <tr>
            	<td valign="top"><?php echo $language['editer_name']; ?>:</td>
            	<td><input type="text" id="title" style="width: 200px;" value="No name" /></td>
            </tr>
            <tr>
            	<td valign="top"><?php echo $language['editer_description']; ?>:</td>
            	<td><textarea id="description" style="width: 200px;"></textarea></td>
            </tr>
            </table>
        </li>
    </ul>
    
    
    <?php } elseif($_GET['type']=='url'){ ?>
    <h1><?php echo $language['editer_file_url_t']; ?></h1>
    <ul class="url">
        <li>
            <table>
            <tr>
            	<td valign="top" width="100px"><?php echo $language['editer_file_url']; ?>:</td>
            	<td><input type="text" id="url" style="width: 200px;" value="http://" /></td>
            </tr>
            <tr>
            	<td valign="top"><?php echo $language['editer_name']; ?>:</td>
            	<td><input type="text" id="title" style="width: 200px;" value=" " /></td>
            </tr>
            <tr>
            	<td valign="top"><?php echo $language['editer_description']; ?>:</td>
            	<td><textarea id="description" style="width: 200px;"></textarea></td>
            </tr>
            </table>
        </li>
    </ul>
    
    <?php } elseif($_GET['type']=='lib'){ ?>
    <script language="javascript">
        $(document).ready(function(){
            $('.ok').click(function(){
                $('#filedemo').hide();  
                $('.info').show();
                $('#url').val($(this).attr('value')); 
                $('#title').val($(this).attr('name')); 
                $('#description').text($(this).attr('desc'));
            });
        });
    </script>
    <h1><?php echo $language['editer_file_lib_t']; ?></h1>
    <div id="filedemo">
        <table>
            <?php 
                $current_page = ($_GET['page'])?$_GET['page']:1;
                $start = 5*($current_page-1);
                $datas = @mysql_query("SELECT * FROM w3style_datas WHERE data_type=3 ORDER BY id DESC LIMIT ".$start.",5");
                $total = @mysql_num_rows(@mysql_query("SELECT * FROM w3style_datas WHERE data_type=3"));
                while ($data = mysql_fetch_array ($datas))
                {
                    $thumb = '../icons/'.type($data['data_url']).'.png';
            ?>
            <tr>
                <td><img src="<?php echo $thumb; ?>" /></td>
                <td style="max-width: 280px; width: 280px;">
                    <p><?php echo $data['data_name']; ?></p>
                    <p><?php echo formatTime($data['data_time'],1); ?></p>
                </td>
                <td><button class="ok" value="<?php echo $data['data_url']; ?>" name="<?php echo $data['data_name']; ?>" desc="<?php echo $data['data_info']; ?>" type="<?php echo $type; ?>"><?php echo $language['editer_ok']; ?></button></td>
            </tr>
            <?php
                }
             ?>
        </table>
    
        <?php 
            echo paging(5,$current_page,$total,'insert_file.php?type=lib','&page=',false);
        ?>
    </div>
    <ul class="url">
        <li class="info">
            <table>
            <input id="url" type="hidden" />
            <tr>
            	<td valign="top"><?php echo $language['editer_name']; ?>:</td>
            	<td><input type="text" id="title" style="width: 200px;" value=" " /></td>
            </tr>
            <tr>
            	<td valign="top"><?php echo $language['editer_description']; ?>:</td>
            	<td><textarea id="description" style="width: 200px;"></textarea></td>
            </tr>
            </table>
        </li>
    </ul>
    <?php } ?>
    </div>
    <div align="right" style="padding-top: 5px;"><input type="submit" value="<?php echo $language['editer_insert']; ?>" onClick="insertFile();" style="font-size: 12px;" />&nbsp;<input type="submit" value="<?php echo $language['editer_cancel']; ?>" onClick="parent.$.akModalRemove();" style="font-size: 12px;" /></div>
</div>
</body>
</html>
<?php }

else echo "Hacking attempt";
?>