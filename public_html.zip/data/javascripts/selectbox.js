$().ready(function() {  
$('#add').click(function() {  
	return !$('#select1 option:selected').remove().appendTo('#select2');  
});  
$('#remove').click(function() {  
	return !$('#select2 option:selected').remove().appendTo('#select1');  
}); 
$('form').submit(function() {
	$('#select2 option').each(function(i) {
	$(this).attr("selected", "selected");
});
});
}); 