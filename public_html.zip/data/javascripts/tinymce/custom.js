$(document).ready(function(){
	tinymce.init({
	    selector: "#Editor",
	    theme: "modern",
	    menubar:false,
	    language : 'vi_VN',
	    relative_urls : false,
	    remove_script_host : false,
		convert_urls : true,
	    plugins: [
	         "advlist autolink link image lists charmap print preview hr anchor pagebreak spellchecker",
	         "searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking",
	         "save table contextmenu directionality emoticons template paste textcolor"
	   ],
	   toolbar: "undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | code | unlink link insert_image | print preview media fullpage | forecolor backcolor emoticons",
	   setup : function(ed) {
	      // Register example button
	      
	      ed.addButton('insert_image', {
	         title : 'Chèn ảnh',
	         image : '../data/javascripts/tinymce/icons/insert_picture.gif',
	         onclick : function() {
	            // ed.windowManager.alert('Hello world!! Selection: ' + ed.selection.getContent({format : 'text'}));
	            $.showAkModal('../data/javascripts/editor/popups/insert_image.php?wysiwyg=20&type=up','Image',450,400);
	         }
	      });
	   }
	});
	
	$('.product-images a.remove').live('click', function(){
		var url = $(this).closest('tr').attr('data-url');
		var value = $('input[name=attach_image]').val();		
		$('input[name=attach_image]').val(value.replace(url + ',', ''));
		$(this).closest('tr').remove();
	});
});
function insertHtml(html, id){
	tinyMCE.activeEditor.execCommand('mceInsertContent', false, html);
}