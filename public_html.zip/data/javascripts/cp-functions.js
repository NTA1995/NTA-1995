var date = new Date();
date.setTime(date.getTime() + (86400*360));

function Nb(str){
    var strlen = str.length;
    if(strlen > 9) var str = str.substring(0, strlen - 9) + '.' + str.substring(strlen - 9, strlen - 6) + '.' + str.substring(strlen - 6, strlen - 3) + '.' + str.substring(strlen - 3, strlen);
    else if(strlen > 6) var str = str.substring(0, strlen - 6) + '.' + str.substring(strlen - 6, strlen - 3) + '.' + str.substring(strlen - 3, strlen);
    else if(strlen > 3) var str = str.substring(0, strlen - 3) + '.' + str.substring(strlen - 3, strlen);
    return str;
}

function showNumber(){
    $('#IDprice').parent().next().text(Nb($('#IDprice').val()));
    $('#IDfree').parent().next().text(Nb($('#IDfree').val()));
    $('#IDtotal').parent().next().text(Nb($('#IDtotal').val()));
}

$(function() {
    $('.start-toggle').click(function() {
        if ($(this).attr("class") == 'start-toggle toggle-show') {
            $(this).addClass('toggle-hidden').removeClass('toggle-show');
            $('#div-'+this.id).slideUp('slow');
            $.cookie(this.id,'hidden');
        }
        else {
            $(this).addClass('toggle-show').removeClass('toggle-hidden');
            $('#div-'+this.id).slideDown('slow');
            $.cookie(this.id,'show');
        }
    });
            
    $('div .toggle').parent().click(function()  {
        $('ul.sm:visible').slideUp('slow');
        $(this).next().slideDown('slow');
        return false;
    });
});