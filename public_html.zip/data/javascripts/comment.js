
$(document).ready(function(){
	//global vars
	var form = $("#customForm");
	var comment = $("#comment");
    
    
	comment.blur(validateCommment);
	comment.keyup(validateCommment);
    
    form.submit(function(){
		if(validateCommment())
			return true
		else
			return false;
	});
    
    function validateCommment(){
        var filter = /[<>]/;
		if( filter.test(comment.val()) | comment.val().length < 9){
			comment.addClass("error");
			return false;
		}
		//are valid
		else{
			comment.removeClass("error");
			return true;
		}
	}
});