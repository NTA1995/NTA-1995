$(function() {
    $('h3.cat a').click(function()  {
        $('ul.cat:visible').slideUp('slow');
        $(this).parent().next().slideDown('slow');
        return false;
    });
    
    $('#slideshow').cycle({
        fx:         'scrollHorz', 
        timeout:    6500, 
        next:       '#Next', 
        prev:       '#Prev'
	});
    
    $('#news').cycle({
        fx:         'blindY', 
        timeout:    10000
	});
    
    $('.en').click(function(){
        langEN();
    });
    
    $('.vi').click(function(){
        langVN();
    });
    
    if(parseInt($(document).width()) >= 1250){
        $('#AdsLeft').fadeIn('slow');
        $('#AdsRight').fadeIn('slow');
    }
    
    $(window).scroll(function(){
        if(parseInt($(document).scrollTop()) >= 150){
            $('#AdsLeft').stop(true).animate({'top': ($(document).scrollTop() + 5) + 'px'},1500);
            $('#AdsRight').stop(true).animate({'top': ($(document).scrollTop() + 5) + 'px'},1500);
        }
        else {
            $('#AdsLeft').stop(true).animate({'top': ($(document).scrollTop() + 130) + 'px'},1500);
            $('#AdsRight').stop(true).animate({'top': ($(document).scrollTop() + 130) + 'px'},1500);
        }
    });
    
    $(window).resize(function(){
        if(parseInt($(document).width()) < 1250){
            $('#AdsLeft').hide();
            $('#AdsRight').hide();
        }
        else {
            $('#AdsLeft').show();
            $('#AdsRight').show();
        }
    });
    
    $('.faq').click(function(){
        var faqID = this.id;
        faqID = faqID.replace('faq-title-', '');
        faqID = '#faq-' + faqID;
        $.scrollTo(faqID, {duration: 800, axis:"y", onAfter:function(){
            $(faqID).effect("highlight", {color: "silver"}, 2000); }
        });

    });

	$(".return-top").click(function() {
		$.scrollTo("body", {duration: 800, axis:"y"});
	});
    
    shopcart();  
    $('.addcart-small').click(function(){
        var id = $(this).attr('accesskey');
        shopcart(id);
        $.growlUI('Đã thêm vào giỏ hàng!'); 
    }); 

    poll();
    
    $('.imgdemo a').hover(
        function(e){
            $('#imgdemo img').attr('src', $(this).attr('rel'));
            $('#imgdemo').show();
            $(this).mousemove(function(e){
                if($(window).height()/2 > e.clientY){
                    $('#imgdemo').css('top', (e.clientY + 20)+'px');
                    $('#imgdemo').css('bottom', null);
                } 
                else {
                    $('#imgdemo').css('top', null);
                    $('#imgdemo').css('bottom', ($(window).height()- e.clientY + 20)+'px');
                }
                
                if($(window).width()/2 > e.clientX){
                    $('#imgdemo').css('left', (e.clientX + 20)+'px');
                    $('#imgdemo').css('right', null);
                }
                else {
                    $('#imgdemo').css('left', null);
                    $('#imgdemo').css('right', ($(window).width() - e.clientX + 20)+'px');
                }
            });
        },
        function(){
            $('#imgdemo img').attr('src', null);
            $('#imgdemo').hide();
        }
    );
    
    $('#list-full').click(function(){
        $.cookie('list', null, { path: '/', expires: date });
        location.reload();
    });
    
    $('#list-icon').click(function(){
        $.cookie('list', 'icon', { path: '/', expires: date });
        location.reload();
    });
    
    $('#list-order').change(function(){
        $.cookie('order', $(this).val(), { path: '/', expires: date });
        location.reload();
    });
        
});