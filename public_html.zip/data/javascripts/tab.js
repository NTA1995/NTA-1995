$(function(){
    $(".tab li").click(function(){
        switch(this.id){
            case "hview":
				$("#hview").addClass("active");
				$("#hnew").removeClass("active");
				$("#hfree").removeClass("active");
				$("table.hview").show();
				$("table.hnew").hide();
				$("table.hfree").hide();
			break;
            case "hnew":
				$("#hview").removeClass("active");
				$("#hnew").addClass("active");
				$("#hfree").removeClass("active");
				$("table.hview").hide();
				$("table.hnew").show();
				$("table.hfree").hide();
			break;
            case "hfree":
				$("#hview").removeClass("active");
				$("#hnew").removeClass("active");
				$("#hfree").addClass("active");
				$("table.hview").hide();
				$("table.hnew").hide();
				$("table.hfree").show();
			break;
        }
		return false;
    });
});