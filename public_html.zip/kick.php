<?php
define('W3STYLE',true);
include('#includes/config.php');    


if(@mysql_query("UPDATE w3style_options SET option_value = '0' WHERE option_key = 'kick'")) {
    setcookie("website", "", time() - 3600);
    Redirect("", "/");
} else {

}


?>